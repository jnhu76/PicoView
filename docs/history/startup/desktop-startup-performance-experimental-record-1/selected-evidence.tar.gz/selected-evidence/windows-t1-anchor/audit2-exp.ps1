# AUDIT-2 experiment runner: strict ABBA interleaving of two env conditions
# on ONE instrumented binary. Records per-run: condition, external READY
# detection (poll), kernel-create lag, create->print, in-process present_done.
param(
  [int]$Pairs = 8,
  [string]$A = "",
  [string]$B = "",
  [string]$Exe = "C:/Users/fred1/source/pocketjs-audit2/hosts/desktop/target/release/pocket-desktop-host.exe",
  [string]$OutDir = "C:/Users/fred1/source/PicoView/evidence/tmp/logs",
  [string]$Label = "exp"
)
$ErrorActionPreference = 'Stop'
$env:POCKET_MEM_STAGE = "1"
$env:POCKETJS_DIST = "C:/Users/fred1/source/pocketjs/dist"
# clear ALL audit knobs between arms (hygiene: presence-based flags must clear)
foreach ($k in @("POCKET_AUDIT_DELAY_GPU","POCKET_AUDIT_DELAY_EVAL","POCKET_AUDIT_DELAY_OFFLOAD","POCKET_AUDIT_EARLY_ADAPTER","POCKET_AUDIT_EARLY_RELEASE","POCKET_AUDIT_WARM_WINDOW")) {
  Remove-Item "Env:$k" -ErrorAction SilentlyContinue
}
Get-ChildItem Env: | Where-Object { $_.Name -like "POCKET_AUDIT_*" } | ForEach-Object {
  Remove-Item "Env:$($_.Name)" -ErrorAction SilentlyContinue
}
function Parse-KV($s) {
  $h = @{}
  if ($s) { foreach ($p in ($s -split ';')) { $kv = $p -split '=', 2; if ($kv.Count -eq 2) { $h[$kv[0]] = $kv[1] } } }
  return $h
}
$envA = Parse-KV $A
$envB = Parse-KV $B
$rows = New-Object System.Collections.Generic.List[string]
$rows.Add("label,i,spawnMs,createLag,printToCreate,presentDoneProc,detMs")
$order = @()
for ($i = 0; $i -lt $Pairs; $i++) { $order += @('A','B') }
for ($i = 0; $i -lt $order.Count; $i++) {
  $cond = $order[$i]
  $e = if ($cond -eq 'A') { $envA } else { $envB }
  foreach ($k in @("POCKET_AUDIT_DELAY_GPU","POCKET_AUDIT_DELAY_EVAL","POCKET_AUDIT_DELAY_OFFLOAD","POCKET_AUDIT_EARLY_ADAPTER","POCKET_AUDIT_EARLY_RELEASE","POCKET_AUDIT_WARM_WINDOW")) {
    Remove-Item "Env:$k" -ErrorAction SilentlyContinue
  }
  Get-ChildItem Env: | Where-Object { $_.Name -like "POCKET_AUDIT_*" } | ForEach-Object {
    Remove-Item "Env:$($_.Name)" -ErrorAction SilentlyContinue
  }
  foreach ($k in $e.Keys) { Set-Item "Env:$k" $e[$k] }
  $out = "$OutDir/audit2-$Label-$cond-$i.out"
  $err = "$OutDir/audit2-$Label-$cond-$i.err"
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  $t0wall = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  $p = Start-Process -FilePath $Exe `
    -ArgumentList "--app picoview-a6 --announce-ready --trace-frames --quit-after 40" `
    -RedirectStandardOutput $out -RedirectStandardError $err -PassThru -WindowStyle Minimized
  $spawnMs = $sw.ElapsedMilliseconds
  $createMs = [long][math]::Round(($p.StartTime.ToUniversalTime() - [DateTime]'1970-01-01').TotalMilliseconds)
  $detMs = -1
  while ($sw.ElapsedMilliseconds -lt 15000) {
    $fs = [System.IO.File]::Open($out, 'Open', 'Read', [System.IO.FileShare]::ReadWrite)
    $txt = ([System.IO.StreamReader]::new($fs)).ReadToEnd()
    if ($txt.Contains("READY")) { $detMs = $sw.ElapsedMilliseconds; break }
    if ($p.HasExited) { break }
    Start-Sleep -Milliseconds 5
  }
  $null = $p.WaitForExit(5000)
  $readyLine = (Get-Content $out | Select-String "^READY").Line
  $epoch = if ($readyLine -match "READY (\d+)") { [long]$Matches[1] } else { -1 }
  $pd = (Select-String -Path $err -Pattern "present_done,(\d+)ms" | Select-Object -First 1)
  $pdMs = if ($pd) { [int]$pd.Matches[0].Groups[1].Value } else { -1 }
  $rows.Add("$cond,$i,$spawnMs,$($createMs - $t0wall),$(if ($epoch -ge 0) { $epoch - $createMs } else { -1 }),$pdMs,$detMs")
  Write-Output $rows[$rows.Count-1]
}
$rows | Set-Content -Path "$OutDir/audit2-$Label.csv"
Write-Output "csv: $OutDir/audit2-$Label.csv"
