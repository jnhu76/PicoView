$ErrorActionPreference = 'Continue'
$os = Get-CimInstance Win32_OperatingSystem
"OS: $($os.Caption) build $($os.BuildNumber)"
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
"CPU: $($cpu.Name) | LPs: $($cpu.NumberOfLogicalProcessors)"
"RAM_GiB: $([math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2))"
$gpu = Get-CimInstance Win32_VideoController | Select-Object -First 1
"GPU: $($gpu.Name) | driver $($gpu.DriverVersion) | refresh $($gpu.CurrentRefreshRate)"
"PowerPlan: $((powercfg /getactivescheme) -replace '^\s+','')"
"Uptime_h: $([math]::Round(((Get-Date) - $os.LastBootUpTime).TotalHours,2))"
"FreeRAM_GiB: $([math]::Round($os.FreePhysicalMemory/1MB,2))"
Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct | ForEach-Object { "AV: $($_.displayName)" }
$svc = Get-Service WinDefend -ErrorAction SilentlyContinue
"WinDefend: $($svc.Status)"
"CPUload_now_pct: $((Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average)"
"Timestamp: $(Get-Date -Format o)"
