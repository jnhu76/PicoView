# A7 startup probe (BENCHMARK #5/#6): N cold process spawns; measures
# T0_ACTIVATION_REQUEST -> READY (T2 usable-window proxy) and
# T0 -> IMGREADY (T6 present-submitted first-useful-image proxy) with a
# monotonic Stopwatch (QPC). Stdout is redirected to a per-run file and
# polled at ~10 ms granularity (blocking reads cannot be watchdogged in
# PowerShell; detection latency <= ~15 ms is inside the +/-60 ms probe
# tolerance validated by validate-probe.ps1, which shares this core).
param(
  [int]$Runs = 55,
  [string]$Exe = "C:/Users/fred1/source/pocketjs/hosts/desktop/target/release/pocket-desktop-host.exe",
  [string]$Image = "C:/Users/fred1/source/PicoView/evidence/tmp/samples/picoview-12mp.jpg",
  [string]$Out = "C:/Users/fred1/source/PicoView/evidence/tmp/logs/a7-startup.csv",
  [int]$TimeoutMs = 15000,
  [string]$App = "picoview-a6",
  [string]$Mode = "image"
)
$ErrorActionPreference = 'Stop'
$guestArgs = switch ($Mode) {
  "image" { "--a3-harness --a3-file `"$Image`"" }
  "window" { "" }
  default { "--a3-harness --a3-file `"$Image`"" }
}
$rows = New-Object System.Collections.Generic.List[string]
$rows.Add("run,spawnMs,readyMs,imgReadyMs,exitOk")
$misses = 0
for ($i = 0; $i -lt $Runs; $i++) {
  $tmp = "$Out.run$i.tmp"
  if (Test-Path $tmp) { Remove-Item $tmp -Force }
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  $p = Start-Process -FilePath $Exe `
    -ArgumentList "--app $App $guestArgs --announce-ready --quit-after 40" `
    -RedirectStandardOutput $tmp -RedirectStandardError "$tmp.err" -PassThru -WindowStyle Minimized
  $spawnMs = $sw.ElapsedMilliseconds
  $readyMs = -1; $imgMs = -1
  while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
    $fs = [System.IO.File]::Open($tmp, 'Open', 'Read', [System.IO.FileShare]::ReadWrite)
    $txt = ([System.IO.StreamReader]::new($fs)).ReadToEnd()
    # IMGREADY must be tested first: "READY" is a substring of "IMGREADY",
    # so the previous order structurally collapsed image-mode readyMs onto
    # imgMs (C1 review finding).
    if ($txt.Contains("IMGREADY")) { $imgMs = $sw.ElapsedMilliseconds; if ($readyMs -lt 0) { $readyMs = $imgMs } ; break }
    if ($readyMs -lt 0 -and $txt.Contains("READY")) { $readyMs = $sw.ElapsedMilliseconds }
    if ($p.HasExited -and $imgMs -lt 0 -and -not $txt.Contains("READY")) { break }
    Start-Sleep -Milliseconds 10
  }
  if (-not $p.WaitForExit(3000)) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
  $exitOk = if ($Mode -eq "image") { $imgMs -ge 0 -and $readyMs -ge 0 } else { $readyMs -ge 0 }
  if (-not $exitOk) { $misses++ }
  $rows.Add("$i,$spawnMs,$readyMs,$imgMs,$exitOk")
  Remove-Item $tmp, "$tmp.err" -Force -ErrorAction SilentlyContinue
}
$rows | Set-Content -Path $Out
$ok = $rows | Select-Object -Skip 1 | ForEach-Object {
  $f = $_.Split(",")
  [pscustomobject]@{ spawn = [int]$f[1]; ready = [int]$f[2]; img = [int]$f[3]; ok = $f[4] }
} | Where-Object { if ($Mode -eq "image") { $_.ok -eq "True" } else { $_.ready -ge 0 } }
$spawn = $ok | ForEach-Object { $_.spawn } | Sort-Object
$ready = $ok | ForEach-Object { $_.ready } | Sort-Object
$img = $ok | ForEach-Object { $_.img } | Sort-Object
function Pct($sorted, $p) { $sorted[[Math]::Min($sorted.Count - 1, [Math]::Ceiling($p / 100.0 * $sorted.Count) - 1)] }
Write-Output ("runs=$Runs ok={0} misses={1}" -f @($ok).Count, $misses)
Write-Output ("T1_spawn    P50={0} P95={1}" -f (Pct $spawn 50), (Pct $spawn 95))
Write-Output ("T0_READY    P50={0} P95={1}" -f (Pct $ready 50), (Pct $ready 95))
Write-Output ("T0_IMGREADY P50={0} P95={1}" -f (Pct $img 50), (Pct $img 95))
$rt = $ok | ForEach-Object { $_.ready - $_.spawn } | Sort-Object
$ri = $ok | ForEach-Object { $_.img - $_.spawn } | Sort-Object
Write-Output ("T1_TO_T2    P50={0} P95={1}" -f (Pct $rt 50), (Pct $rt 95))
Write-Output ("T1_TO_T6    P50={0} P95={1}" -f (Pct $ri 50), (Pct $ri 95))
