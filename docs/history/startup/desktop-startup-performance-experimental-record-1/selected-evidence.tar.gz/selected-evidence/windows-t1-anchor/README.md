# WINDOWS-T1-ANCHOR — raw values cited by the consolidated record

Small, portable extracts of the #40 audit's raw artifacts, added in review
round 1 so the numbers quoted by
`docs/DESKTOP-STARTUP-PERFORMANCE-EXPERIMENTAL-RECORD-1.md` are checkable
without the host worktree's full `evidence/tmp/logs/` tree.

## warm-window-second-create.txt

The six warm-window-creates behind "≈13 ms intrinsic winit/CreateWindowExW
cost": raw `A7EVENT,dur,warm_window_create,<us>` values from
`audit2-ww-{0..5}.err` — 14804, 13161, 12627, 12503, 13174, 13374 µs
(median 13.17 ms linear / 13.16 ms nearest-rank; mean 13.27; max 14.80).

## join3-hello.csv

The persisted join3 hello-world family behind the pre-main control row
(`docs/audit2-join3.ps1`): `printToCreate` = kernel create → first print,
8 runs: 114, 116, 121, 126, 123, 130, 124, 122 ms
(median 122.5 linear / 122 nearest-rank; mean 122.0).

Both files are byte copies of the host artifacts
(`C:\Users\fred1\source\PicoView\evidence\tmp\logs\`).
