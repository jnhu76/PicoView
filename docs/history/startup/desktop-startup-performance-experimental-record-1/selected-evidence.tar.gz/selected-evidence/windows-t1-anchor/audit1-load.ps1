# STARTUP-LAST-MILE-REALITY-AUDIT-1 E3: background-load intervention.
# Block A (quiet) -> Block B (loaded: 12 CPU-burn workers) -> Block C (quiet).
# Same exe, interleaved-by-block ABA design; records T0->IMGREADY per spawn.
param(
  [int]$PerBlock = 10,
  [string]$Exe = "C:/Users/fred1/source/pocketjs/hosts/desktop/target/release/pocket-desktop-host.exe",
  [string]$Image = "C:/Users/fred1/source/PicoView/evidence/tmp/samples/picoview-12mp.jpg",
  [string]$Out = "C:/Users/fred1/source/PicoView/evidence/tmp/logs/audit1-load.csv",
  [int]$TimeoutMs = 15000,
  [int]$WorkerCount = 12
)
$ErrorActionPreference = 'Stop'
$rows = New-Object System.Collections.Generic.List[string]
$rows.Add("block,arm,run,cpuLoad,spawnMs,imgReadyMs")
function Spawn-One([string]$block, [string]$arm, [int]$run) {
  $load = [int](Get-CimInstance Win32_Processor).LoadPercentage
  $tmp = "$Out.$block$run.tmp"
  if (Test-Path $tmp) { Remove-Item $tmp -Force }
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  $p = Start-Process -FilePath $Exe `
    -ArgumentList "--app picoview-a6 --a3-harness --a3-file `"$Image`" --announce-ready --quit-after 40" `
    -RedirectStandardOutput $tmp -RedirectStandardError "$tmp.err" -PassThru -WindowStyle Minimized
  $spawnMs = $sw.ElapsedMilliseconds
  $imgMs = -1
  while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
    $fs = [System.IO.File]::Open($tmp, 'Open', 'Read', [System.IO.FileShare]::ReadWrite)
    $txt = ([System.IO.StreamReader]::new($fs)).ReadToEnd()
    if ($txt.Contains("IMGREADY")) { $imgMs = $sw.ElapsedMilliseconds; break }
    if ($p.HasExited -and $imgMs -lt 0) { break }
    Start-Sleep -Milliseconds 5
  }
  if (-not $p.WaitForExit(3000)) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
  $rows.Add("$block,$arm,$run,$load,$spawnMs,$imgMs")
  Remove-Item $tmp, "$tmp.err" -Force -ErrorAction SilentlyContinue
}
$workers = @()
foreach ($block in @(@('A','quiet'), @('B','loaded'), @('C','quiet'))) {
  $name = $block[0]
  if ($name -eq 'B') {
    $workers = @()
    $cmd = '$sw=[Diagnostics.Stopwatch]::StartNew(); while($sw.ElapsedMilliseconds -lt 120000){ $x=1.0001; foreach($i in 1..200000){$x=[math]::Sqrt($x*$i+1)} }'
    for ($w = 0; $w -lt $WorkerCount; $w++) {
      $workers += (Start-Process -FilePath 'powershell' -ArgumentList @('-NoProfile', '-Command', $cmd) -WindowStyle Hidden -PassThru)
    }
    Start-Sleep -Milliseconds 800
  }
  for ($r = 0; $r -lt $PerBlock; $r++) { Spawn-One $name $block[1] $r }
  if ($name -eq 'B') { $workers | ForEach-Object { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }; $workers = @() }
}
$rows | Set-Content -Path $Out
$ok = $rows | Select-Object -Skip 1 | ForEach-Object {
  $f = $_.Split(",")
  [pscustomobject]@{ block = $f[0]; load = [int]$f[3]; img = [int]$f[5] }
} | Where-Object { $_.img -ge 0 }
foreach ($b in 'A','B','C') {
  $v = ($ok | Where-Object { $_.block -eq $b } | ForEach-Object { $_.img } | Sort-Object)
  $l = ($ok | Where-Object { $_.block -eq $b } | Measure-Object load -Average).Average
  if ($v.Count -gt 0) {
    Write-Output ("block $b n={0} load_avg={1:n0}% P50={2} min={3} max={4}" -f $v.Count, $l, $v[[int][Math]::Floor(($v.Count-1)/2)], $v[0], $v[$v.Count-1])
  }
}
