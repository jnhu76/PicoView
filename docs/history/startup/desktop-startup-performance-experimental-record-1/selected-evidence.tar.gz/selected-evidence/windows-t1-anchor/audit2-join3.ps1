# AUDIT-2 join v3 (review fix): PERSISTED wall-clock join for the generic
# pre-main control. Appends every run to a CSV so all quoted numbers are
# recomputable from artifacts.
param(
  [int]$Runs = 6,
  [string]$Exe = "C:/Users/fred1/source/PicoView/evidence/tmp/audit2-hello/target/release/hello.exe",
  [string]$Match = "HELLO",
  [string]$ArgList = "",
  [string]$OutDir = "C:/Users/fred1/source/PicoView/evidence/tmp/logs",
  [string]$Label = "join3"
)
$ErrorActionPreference = 'Stop'
if ($Exe -like "*pocket-desktop-host*") {
  $env:POCKETJS_DIST = "C:/Users/fred1/source/pocketjs/dist"
}
$rows = New-Object System.Collections.Generic.List[string]
$rows.Add("label,i,spawnMs,createLag,printToCreate,detMs")
for ($i = 0; $i -lt $Runs; $i++) {
  $out = "$OutDir/audit2-$Label-$i.out"
  $err = "$OutDir/audit2-$Label-$i.err"
  $t0 = [System.Diagnostics.Stopwatch]::StartNew()
  $t0wall = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  if ($ArgList) {
    $p = Start-Process -FilePath $Exe -ArgumentList $ArgList `
      -RedirectStandardOutput $out -RedirectStandardError $err -PassThru -WindowStyle Minimized
  } else {
    $p = Start-Process -FilePath $Exe `
      -RedirectStandardOutput $out -RedirectStandardError $err -PassThru -WindowStyle Minimized
  }
  $spawnMs = $t0.ElapsedMilliseconds
  $createMs = [long][math]::Round(($p.StartTime.ToUniversalTime() - [DateTime]'1970-01-01').TotalMilliseconds)
  $detMs = -1
  while ($t0.ElapsedMilliseconds -lt 15000) {
    $fs = [System.IO.File]::Open($out, 'Open', 'Read', [System.IO.FileShare]::ReadWrite)
    $txt = ([System.IO.StreamReader]::new($fs)).ReadToEnd()
    if ($txt.Contains($Match)) { $detMs = $t0.ElapsedMilliseconds; break }
    if ($p.HasExited) { break }
    Start-Sleep -Milliseconds 5
  }
  if (-not $p.WaitForExit(5000)) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
  $line = (Get-Content $out | Select-String "^$Match").Line
  $epoch = if ($line -match "$Match (\d+)") { [long]$Matches[1] } else { -1 }
  $rows.Add("$Label,$i,$spawnMs,$($createMs - $t0wall),$(if ($epoch -ge 0) { $epoch - $createMs } else { -1 }),$detMs")
  Write-Output $rows[$rows.Count-1]
}
$rows | Set-Content -Path "$OutDir/audit2-$Label.csv"
Add-Content -Path "$OutDir/audit2-join3-all.csv" -Value ($rows | Select-Object -Skip 1)
Write-Output "csv: $OutDir/audit2-$Label.csv"
