# WINDOWS-STARTUP-ETW-REALITY-AUDIT-1 — Phase 10 exact-LUID intervention
# runner. Interleaves pristine vs patched arm B runs (same binary; the
# patched behavior is the env-gated ETW_AUDIT_SKIP_LUID exact-LUID skip in
# the vendored wgpu-hal). No ETW capture here: wall-clock authority is the
# NORMTRACE E-series markers only.
# Usage:
#   win-etw-intervene.ps1 -N 20 -OutDir <dir> -SkipLuid 0-1a8f2 `
#     [-BinDir <release-dir>]
param(
    [Parameter(Mandatory = $true)][int]$N,
    [Parameter(Mandatory = $true)][string]$OutDir,
    [Parameter(Mandatory = $true)][string]$SkipLuid,
    [string]$BinDir = "C:\Users\fred1\source\pocketjs-win-etw\target-win-etw\release"
)
$ErrorActionPreference = "Stop"
$binB = Join-Path $BinDir "examples\norm-b.exe"
$pristineDir = Join-Path $OutDir "pristine"
$patchedDir = Join-Path $OutDir "patched"
New-Item -ItemType Directory -Force -Path $pristineDir | Out-Null
New-Item -ItemType Directory -Force -Path $patchedDir | Out-Null

$env:NORMTRACE = "1"
$env:POCKET_GPU_BACKEND = "DX12"
$env:POCKET_FORCE_SCALE = "1.0"
Remove-Item Env:ETW_AUDIT_SKIP_LUID -ErrorAction SilentlyContinue

$counts = @{ pristine = 0; patched = 0 }
$slot = 0
while ($counts["pristine"] -lt $N -or $counts["patched"] -lt $N) {
    $busy = Get-Process -Name cargo, rustc -ErrorAction SilentlyContinue
    if ($busy) { Write-Output "slot-$slot SKIPPED_BUSY_BUILD"; Start-Sleep -Seconds 5; continue }
    # Randomized interleave that stays balanced: coin flip per slot, forced
    # to the unfinished variant once the other reaches N.
    $variant = if ($counts["pristine"] -ge $N) { "patched" }
               elseif ($counts["patched"] -ge $N) { "pristine" }
               else { @( "pristine", "patched" )[(Get-Random -Maximum 2)] }
    $dir = if ($variant -eq "pristine") { $pristineDir } else { $patchedDir }
    $i = $counts[$variant]
    $log = Join-Path $dir ("run-{0:d3}.log" -f $i)
    $out = Join-Path $dir ("run-{0:d3}.out" -f $i)
    if ($variant -eq "patched") { $env:ETW_AUDIT_SKIP_LUID = $SkipLuid }
    else { Remove-Item Env:ETW_AUDIT_SKIP_LUID -ErrorAction SilentlyContinue }
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $p = Start-Process -FilePath $binB -RedirectStandardError $log -RedirectStandardOutput $out -PassThru
    $p.WaitForExit()
    $sw.Stop()
    Add-Content -Path $log -Value "WALL_SPAWN_EXIT_MS=$($sw.ElapsedMilliseconds),exitcode=$($p.ExitCode)"
    $counts[$variant] = $i + 1
    $slot++
    Start-Sleep -Milliseconds 400
}
Write-Output "INTERVENE-DONE pristine=$($counts['pristine']) patched=$($counts['patched']) outdir=$OutDir skip=$SkipLuid"
