#!/usr/bin/env python3
"""WINDOWS-STARTUP-ETW-REALITY-AUDIT-1 — Phase 10 exact-LUID intervention
comparator. Parses pristine/ and patched/ norm-b batch dirs (NORMTRACE logs)
and reports E00->E190, adapter E50->E51, per-probe durations, and the
selected-adapter LUID proof (driver +audit_luid=... in BENCHMARK_CONFIG).

Usage: python compare_intervene.py <outdir-with-pristine-and-patched>
"""
import json
import re
import sys
from pathlib import Path

LINE = re.compile(r"^NORMTRACE,run=([^,]*),thread=([^,]*),event=([^,]*),us=(\d+)$")
SELECTED = re.compile(r'"driver":\s*"[^"]*\+audit_luid=([0-9a-f]+-[0-9a-f]+)"')
SKIPPED = re.compile(r"^AUDIT_DXGI_SKIPPED,luid=([^,]+),", re.M)


def stats(vals):
    s = sorted(vals)
    if not s:
        return "n=0"
    def pct(p):
        k = (len(s) - 1) * p
        f = int(k)
        c = min(f + 1, len(s) - 1)
        return s[f] + (s[c] - s[f]) * (k - f)
    return (f"n={len(s)} P50={pct(0.50)/1000:.1f} P95={pct(0.95)/1000:.1f} "
            f"min={s[0]/1000:.1f} max={s[-1]/1000:.1f} IQR={(pct(0.75)-pct(0.25))/1000:.1f} ms")


def parse_dir(d):
    end, adapter, probe0, probe1, sels, skips = [], [], [], [], [], []
    for path in sorted(Path(d).glob("run-*.log")):
        ev = {}
        text = path.read_text(encoding="utf-8", errors="replace")
        for line in text.splitlines():
            m = LINE.match(line.strip())
            if m:
                name, us = m.group(3), int(m.group(4))
                if name not in ev:
                    ev[name] = us
                continue
            if line.startswith("BENCHMARK_CONFIG"):
                s = SELECTED.search(line)
                if s:
                    sels.append(s.group(1))
            if "AUDIT_DXGI_SKIPPED" in line:
                sm = SKIPPED.search(text)
                if sm and sm.group(1) not in skips:
                    skips.append(sm.group(1))
        if "E00_MAIN_ENTRY" in ev and "E190_FIRST_USABLE_PRESENT_SUBMITTED" in ev:
            end.append(ev["E190_FIRST_USABLE_PRESENT_SUBMITTED"] - ev["E00_MAIN_ENTRY"])
        if "E50_ADAPTER_BEGIN" in ev and "E51_ADAPTER_END" in ev:
            adapter.append(ev["E51_ADAPTER_END"] - ev["E50_ADAPTER_BEGIN"])
        if "E50e0_CREATE_DEVICE_0_BEGIN" in ev and "E50f0_CREATE_DEVICE_0_END" in ev:
            probe0.append(ev["E50f0_CREATE_DEVICE_0_END"] - ev["E50e0_CREATE_DEVICE_0_BEGIN"])
        if "E50e1_CREATE_DEVICE_1_BEGIN" in ev and "E50f1_CREATE_DEVICE_1_END" in ev:
            probe1.append(ev["E50f1_CREATE_DEVICE_1_END"] - ev["E50e1_CREATE_DEVICE_1_BEGIN"])
    return {"end": end, "adapter": adapter, "probe0": probe0, "probe1": probe1,
            "selected": sorted(set(sels)), "skipped": skips}


def main():
    root = Path(sys.argv[1])
    p = parse_dir(root / "pristine")
    q = parse_dir(root / "patched")
    for name, d in (("PRISTINE", p), ("PATCHED(skip=%s)" % (q["skipped"] or "?"), q)):
        print(f"== {name}")
        print(f"   E00->E190    {stats(d['end'])}")
        print(f"   E50->E51     {stats(d['adapter'])}")
        print(f"   probe#0      {stats(d['probe0'])}")
        print(f"   probe#1      {stats(d['probe1'])}")
        print(f"   selected luid (from BENCHMARK_CONFIG): {d['selected']}")
        if d["skipped"]:
            print(f"   skip applied to: {d['skipped']}")
    if p["adapter"] and q["adapter"]:
        def med(v):
            s = sorted(v)
            k = (len(s) - 1) * 0.50
            f = int(k)
            c = min(f + 1, len(s) - 1)
            return s[f] + (s[c] - s[f]) * (k - f)
        mp, mq = med(p["adapter"]), med(q["adapter"])
        print(f"== ADAPTER SPAN SHIFT (patched - pristine): {(mq - mp)/1000:+.1f} ms "
              f"(P50 {mp/1000:.1f} -> {mq/1000:.1f})")
        print(f"   selected preserved: pristine={p['selected']} patched={q['selected']} "
              f"-> {'YES' if p['selected'] == q['selected'] and p['selected'] else 'NO/DIFFERS'}")


if __name__ == "__main__":
    main()
