#!/usr/bin/env python3
"""WINDOWS-STARTUP-ETW-ELEVATED-CLOSEOUT-1 analyzer (elevated kernel trace).

Data sources per run (all under one probe dir + run dirs):
  * NORMTRACE E-series log (wall-clock authority, us from process origin);
  * xperf-dumper CSV of the WPR kernel ETL (trace-relative us; CSwitch /
    ReadyThread / process+thread lifetime / stacks / image loads);
  * tracerpt CSV of the same kernel ETL (absolute FILETIME/10 us) used to
    derive the constant trace-relative <-> absolute conversion (delta) from
    two matched event pairs (Process/Start and first ReadyThread);
  * tracerpt CSV of the private user-session ETL (same absolute domain) for
    the child's DxgKrnl / Win32k events.

Modes:
  timeline  --run A0 --pid 19120 --e00-kms X
        print merged child timeline in kernel-relative ms, with E-series
        markers overlaid at e00_kms + us/1000.
  windows   --run A0 --pid 19120 --e00-kms X --win E20:E21 --win E50e0:E50f0
        decompose the given E-series windows into RUNNING / READY / WAITING
        (main thread first), with wait-reason histogram, wait stacks, wake
        sources.  Wall length is taken from the markers (authority).

The alignment (e00-kms) is an input, never a hidden assumption; the tool
prints the structural checks (RUNNING containment of every marker that
Rust emits while executing, image-load placement) that any candidate
alignment must satisfy.
"""
import argparse
import csv
import json
import re
import sys
from pathlib import Path

NORM_RE = re.compile(
    r"^NORMTRACE,run=([^,]*),thread=([^,]*),event=([^,]*),us=(\d+)$")


def load_markers(log_path):
    markers = {}
    for line in Path(log_path).read_text(encoding="utf-8", errors="replace").splitlines():
        m = NORM_RE.match(line.strip())
        if m:
            _r, thread, event, us = m.groups()
            if event not in markers:
                markers[event] = (int(us), thread)
    return markers


def parse_kernel_dumper(csv_path, pid):
    out = {"p_start": None, "p_end": None, "t_start": {}, "t_end": {},
           "cswitch": [], "readythread": [], "stacks": {},
           "image_load": [], "tids": set()}
    pidre = re.compile(r"\(\s*%d\)\s*$" % pid)
    tids_seen = set()
    n_line = 0
    with open(csv_path, encoding="utf-8", errors="replace") as f:
        for line in f:
            n_line += 1
            cls = line.split(",", 1)[0].strip()
            if cls == "Stack":
                row = line.split(",", 5)
                try:
                    ts = int(row[1]); tid = int(row[2])
                except (ValueError, IndexError):
                    continue
                if tid in tids_seen:
                    out["stacks"].setdefault((ts, tid), []).append(
                        (row[4].strip(), row[5].rstrip("\n").strip()))
                continue
            if str(pid) not in line:
                continue
            if cls == "CSwitch":
                row = [p.strip() for p in line.split(",")]
                try:
                    ts = int(row[1])
                except ValueError:
                    continue
                child_new = bool(pidre.search(row[2]))
                child_old = bool(pidre.search(row[8]))
                if not (child_new or child_old):
                    continue
                d = {"ts": ts, "new_tid": int(row[3]), "old_tid": int(row[9]),
                     "old_state": row[12], "wait_reason": row[13],
                     "cpu": int(row[16]) if row[16].lstrip("-").isdigit() else -1,
                     "new_is_child": child_new, "old_is_child": child_old}
                if child_new:
                    tids_seen.add(d["new_tid"])
                if child_old:
                    tids_seen.add(d["old_tid"])
                out["cswitch"].append(d)
            elif cls == "ReadyThread":
                row = [p.strip() for p in line.split(",")]
                if not pidre.search(row[4]):
                    continue
                try:
                    ts = int(row[1])
                except ValueError:
                    continue
                out["readythread"].append({
                    "ts": ts, "rdy_tid": int(row[5]), "by_pid": row[2],
                    "by_tid": int(row[3]), "adjust": row[6], "cpu": row[8]})
            elif cls == "P-Start":
                row = [p.strip() for p in line.split(",")]
                if pidre.search(row[2]):
                    out["p_start"] = int(row[1])
            elif cls == "P-End":
                row = [p.strip() for p in line.split(",")]
                if pidre.search(row[2]):
                    out["p_end"] = int(row[1])
            elif cls == "T-Start":
                row = [p.strip() for p in line.split(",")]
                if pidre.search(row[2]):
                    out["t_start"][int(row[3])] = int(row[1])
                    tids_seen.add(int(row[3]))
            elif cls == "T-End":
                row = [p.strip() for p in line.split(",")]
                if pidre.search(row[2]):
                    out["t_end"][int(row[3])] = int(row[1])
            elif cls == "I-Start":
                row = [p.strip() for p in line.split(",")]
                if pidre.search(row[2]):
                    out["image_load"].append((int(row[1]), row[-1].strip('"')))
    out["tids"] = tids_seen
    return out


def parse_kernel_tracerpt(csv_path, pid):
    res = {"p_start_abs": None, "first_ready_abs": None}
    tag = "0x%X" % pid
    with open(csv_path, encoding="utf-8", errors="replace") as f:
        rdr = csv.reader(f)
        next(rdr, None)
        for row in rdr:
            if len(row) < 21:
                continue
            name = row[0].strip()
            if name == "Process" and row[1].strip() == "Start":
                if row[20].strip() == tag and res["p_start_abs"] is None:
                    res["p_start_abs"] = int(row[16]) / 10.0
            elif name == "Thread" and row[1].strip() == "ReadyThread":
                if res["first_ready_abs"] is None:
                    res["first_ready_abs"] = int(row[16]) / 10.0
    return res


def parse_user_tracerpt(csv_path, pid):
    events = []
    provs = {}
    pidhex = "0x%08X" % pid
    with open(csv_path, encoding="utf-8", errors="replace") as f:
        rdr = csv.reader(f)
        next(rdr, None)
        for row in rdr:
            if len(row) < 20 or row[0].strip() == "EventTrace":
                continue
            if row[9].strip() != pidhex:
                continue
            name = row[0].strip()
            provs[name] = provs.get(name, 0) + 1
            try:
                events.append((float(row[16]) / 10.0, name, int(row[2]),
                               row[1].strip()))
            except ValueError:
                continue
    return events, provs


def _candidates(probe, run, stem):
    """Probe dir CSVs were written with both <run>k-* and <run>-k-* naming."""
    for pat in (f"{run}{stem}", f"{run}-{stem}"):
        p = probe / (pat.format(kind="k") + ".csv")
        if p.exists():
            return p
    for pat in (f"{run}{stem}", f"{run}-{stem}"):
        p = probe / (pat.format(kind="u") + ".csv")
        if p.exists():
            return p
    return None


_SHARED_SYM = None


def shared_sym(probe):
    """Boot-wide symbol dictionary: addresses are stable for the whole boot,
    so symbols resolved once (partial symbol dumps, test dumps) apply to
    every run's kernel ETL on this machine."""
    global _SHARED_SYM
    if _SHARED_SYM is None:
        _SHARED_SYM = load_symdict([
            probe / "A0k-sym.csv", probe / "A0k-full-sym.csv",
            probe / "symtest.csv", probe / "symtest2.csv",
            probe / "../20260914-121456/canary/symtest2.csv"])
    return _SHARED_SYM


def load_run(probe, logs, rd, run, pid, kdump=None):
    probe = Path(probe)
    kdump = Path(kdump) if kdump else _candidates(
        probe, run, "{kind}-full")
    kd = parse_kernel_dumper(str(kdump), pid)
    ktr = kdump.with_name(kdump.name.replace("-full", "-tracerpt"))
    kk = parse_kernel_tracerpt(str(ktr), pid) if ktr.exists() else {
        "p_start_abs": None, "first_ready_abs": None}
    utr = probe / f"{run}u-tracerpt.csv"
    if not utr.exists():
        utr = probe / f"{run}-u-tracerpt.csv"
    uev, provs = parse_user_tracerpt(str(utr), pid) if utr.exists() else ([], {})
    markers = load_markers(Path(logs) / f"{run}.log")
    delta = None
    if kk["p_start_abs"] is not None and kd["p_start"] is not None:
        delta = kk["p_start_abs"] - kd["p_start"]
    by_tid = {}
    for (ts, tid), frames in kd["stacks"].items():
        by_tid.setdefault(tid, []).append((ts, frames))
    for v in by_tid.values():
        v.sort(key=lambda x: x[0])
    kd["stacks_by_tid"] = by_tid
    sym = dict(shared_sym(probe))
    sym.update(load_symdict([probe / f"{run}k-sym.csv",
                             probe / f"{run}-k-sym.csv"]))
    return {"run": run, "pid": pid, "kd": kd, "markers": markers,
            "uev": uev, "provs": provs, "delta": delta, "kk": kk, "sym": sym}


def find_stack(kd, ts, tid, tol=300):
    """Nearest Stack group for (tid) within +-tol us of the switch time."""
    best = None
    for ts2, frames in kd.get("stacks_by_tid", {}).get(tid, []):
        d = abs(ts2 - ts)
        if d <= tol and (best is None or d < best[0]):
            best = (d, frames)
    return best[1] if best else None


def episodes(kd):
    """Per-TID state episodes: list of (t0,t1,state,detail).

    State from the thread's own CSwitch history:
      switch-out -> WAITING (with wait reason / stack candidate);
      a later ReadyThread for the same TID -> READY from that instant;
      switch-in -> RUNNING until the next switch-out.
    """
    evs = sorted(kd["cswitch"], key=lambda d: d["ts"])
    rt_by_tid = {}
    for r in kd["readythread"]:
        rt_by_tid.setdefault(r["rdy_tid"], []).append(r)
    for v in rt_by_tid.values():
        v.sort(key=lambda r: r["ts"])
    per_thread = {}
    last_out = {}   # tid -> (ts, reason)
    for d in evs:
        if d["old_is_child"]:
            last_out[d["old_tid"]] = (d["ts"], d["wait_reason"],
                                      d["old_state"], d["cpu"])
        if d["new_is_child"]:
            t = d["new_tid"]
            eps = per_thread.setdefault(t, [])
            if t in last_out:
                out_ts, reason, ostate, cpu = last_out.pop(t)
                if d["ts"] > out_ts:
                    # ready portion: first ReadyThread in (out_ts, ts)
                    rdy = None
                    for r in rt_by_tid.get(t, []):
                        if out_ts < r["ts"] <= d["ts"]:
                            rdy = r
                            break
                    # A switch-out with OldState Standby/DeferredReady is a
                    # *preempted* thread (still runnable) = READY, not WAITING.
                    preempted = ostate in ("Standby", "DeferredReady")
                    if rdy is not None and rdy["ts"] > out_ts:
                        eps.append((out_ts, rdy["ts"],
                                    "READY" if preempted else "WAITING",
                                    {"reason": reason, "state": ostate,
                                     "by": (f"{rdy['by_pid']} t{rdy['by_tid']}"
                                            if preempted else ""),
                                     "cpu": cpu, "stack_ts": out_ts}))
                        eps.append((rdy["ts"], d["ts"], "READY",
                                    {"by": f"{rdy['by_pid']} t{rdy['by_tid']}",
                                     "cpu": cpu}))
                    else:
                        eps.append((out_ts, d["ts"],
                                    "READY" if preempted else "WAITING",
                                    {"reason": reason, "state": ostate,
                                     "cpu": cpu, "stack_ts": out_ts}))
            eps.append((d["ts"], None, "RUNNING", {"cpu": d["cpu"]}))
    # close RUNNING intervals
    for t, eps in per_thread.items():
        t_end = kd["t_end"].get(t)
        for i, (a, b, st, meta) in enumerate(eps):
            if st == "RUNNING":
                nxt = None
                for (a2, b2, st2, m2) in eps[i + 1:]:
                    nxt = a2
                    break
                eps[i] = (a, nxt if nxt is not None else (t_end or kd["p_end"]),
                          st, meta)
    return per_thread


def main_thread_tid(kd):
    if not kd["t_start"]:
        return None
    return min(kd["t_start"].items(), key=lambda kv: kv[1])[0]


def load_symdict(paths):
    """Build address -> 'image!function' dictionary from symbol-resolved
    dumper CSVs (partial dumps are fine; addresses are boot-stable)."""
    sym = {}
    for p in paths:
        p = Path(p)
        if not p.exists():
            continue
        with open(p, encoding="utf-8", errors="replace") as f:
            for line in f:
                if not line.startswith(" "):
                    continue
                row = line.split(",", 5)
                if row[0].strip() != "Stack":
                    continue
                try:
                    addr = int(row[4].strip(), 16)
                except (ValueError, IndexError):
                    continue
                name = row[5].strip() if len(row) > 5 else ""
                if "!" not in name or "!0x" in name:
                    continue
                sym[addr] = name
    return sym


def render_stack(frames, sym, maxn=16):
    """frames: list of (address, dumper-name). Return module!func list."""
    out = []
    for addr, name in frames[:maxn]:
        a = None
        try:
            a = int(addr, 16)
        except ValueError:
            pass
        if a is not None and a in sym:
            out.append(sym[a])
        else:
            out.append(name.replace("0x0000", "0x").strip())
    return out


def fmt_stack(frames, sym=None, maxn=14):
    if sym:
        frames = render_stack(frames, sym, maxn)
        return " <- ".join(frames)
    return " <- ".join(f.split("!")[-1] if "!" in f else f
                       for f in frames[:maxn])


def print_timeline(run, e00_kms, upto=None, with_stacks=False):
    kd = run["kd"]
    sym = run["sym"]
    print(f"== timeline {run['run']} pid={run['pid']} "
          f"e00_kms={e00_kms} p_start={kd['p_start']/1000:.3f} "
          f"p_end={kd['p_end']/1000:.3f} symdict={len(sym)}")
    print("   E-series markers placed on kernel axis:")
    for k in sorted(run["markers"], key=lambda k: run["markers"][k][0]):
        us = run["markers"][k][0]
        print(f"     {e00_kms + us/1000:10.3f}  {k}")
    for tid in sorted(kd["t_start"], key=lambda t: kd["t_start"][t]):
        print(f"   thread t{tid} start={kd['t_start'][tid]/1000:.3f} "
              f"end={(kd['t_end'].get(tid) or 0)/1000:.3f}")
    print("   images:")
    for ts, name in kd["image_load"]:
        print(f"     {ts/1000:10.3f}  {Path(name).name}")
    mt = main_thread_tid(kd)
    print(f"   main thread = t{mt}")
    for t, eps in sorted(episodes(kd).items()):
        print(f"   -- t{t} episodes:")
        for a, b, st, meta in eps:
            dur = (b - a) / 1000 if b else -1
            extra = ""
            if st == "WAITING":
                extra = f" reason={meta['reason']}"
            elif st == "READY":
                extra = " by=" + (meta.get("by") or f"(preempted/{meta.get('reason')})")
            print(f"     {a/1000:10.3f} -> {(b or 0)/1000:10.3f} "
                  f"{dur:7.3f}ms {st}{extra}")
            if with_stacks and st == "WAITING" and dur >= 1.0:
                stk = find_stack(kd, meta["stack_ts"], t)
                print(f"         stack: {fmt_stack(stk, sym) if stk else 'NO-STACK'}")
    # user-ETL child events histogram on the same axis
    if run["delta"] is not None and run["uev"]:
        hist = {}
        for a, prov, eid, op in run["uev"]:
            kms = (a - run["delta"]) / 1000.0
            key = (prov.split("-")[-1], eid, op)
            h = hist.setdefault(key, [0, kms, kms])
            h[0] += 1; h[2] = kms
        print("   user-ETL child events (kernel-rel ms):")
        for (prov, eid, op), (n, f, l) in sorted(hist.items(),
                                                 key=lambda kv: kv[1][1]):
            print(f"     {f:10.3f}..{l:10.3f}  n={n:5d}  {prov} id={eid} {op}")


def resolve_marker(markers, name):
    if name in markers:
        return name
    cands = [k for k in markers if k.startswith(name)]
    if len(cands) == 1:
        return cands[0]
    # prefer *_BEGIN for bare stage names
    if len(cands) > 1:
        for c in cands:
            if c.endswith("_BEGIN"):
                return c
    return None


def decompose(run, e00_kms, win_name, tids=None, verbose=False):
    """Decompose an E-series window for the given threads (default: all)."""
    markers = run["markers"]
    a_name, b_name = win_name.split(":")
    a_full = resolve_marker(markers, a_name)
    b_full = resolve_marker(markers, b_name)
    if not a_full or not b_full:
        print(f"   {win_name}: markers missing")
        return None
    t0us = markers[a_full][0]
    t1us = markers[b_full][0]
    k0 = e00_kms * 1000.0 + t0us      # us, kernel-relative
    k1 = e00_kms * 1000.0 + t1us
    kd = run["kd"]
    sym = run["sym"]
    wall = (t1us - t0us) / 1000.0
    eps = episodes(kd)
    mt = main_thread_tid(kd)
    use = tids if tids else sorted(eps)
    res = {"window": win_name, "a": a_full, "b": b_full, "wall_ms": wall,
           "k0_ms": k0 / 1000.0, "k1_ms": k1 / 1000.0, "per_thread": {}}
    for t in use:
        tot = {"RUNNING": 0.0, "READY": 0.0, "WAITING": 0.0}
        reasons = {}
        waits = []
        readys = []
        for a, b, st, meta in eps.get(t, []):
            aa, bb = max(a, k0), min(b if b else k1, k1)
            if bb <= aa:
                continue
            d = (bb - aa) / 1000.0
            tot[st] += d
            if st == "WAITING":
                reasons[meta["reason"]] = reasons.get(meta["reason"], 0.0) + d
                stk = find_stack(kd, meta["stack_ts"], t)
                waits.append((aa, bb, d, meta, stk))
            elif st == "READY":
                readys.append((aa, bb, d, meta))
        resid = wall - tot["RUNNING"] - tot["READY"] - tot["WAITING"]
        d = {"running_ms": tot["RUNNING"], "ready_ms": tot["READY"],
             "waiting_ms": tot["WAITING"], "residual_ms": resid,
             "reason_hist": reasons,
             "waits": [{"t0": a, "t1": b, "ms": dd, "reason": m["reason"],
                        "state": m.get("state"),
                        "stack": (render_stack(stk, sym) if stk else None)}
                       for a, b, dd, m, stk in waits],
             "readys": [{"t0": a, "t1": b, "ms": dd,
                         "by": m.get("by") or f"(preempted/{m.get('reason')})"}
                        for a, b, dd, m in readys]}
        res["per_thread"][t] = d
        tag = " (main)" if t == mt else ""
        print(f"   {win_name}{tag} t{t}: wall={wall:.3f} "
              f"RUN={tot['RUNNING']:.3f} READY={tot['READY']:.3f} "
              f"WAIT={tot['WAITING']:.3f} resid={resid:.3f}")
        for r, v in sorted(reasons.items(), key=lambda kv: -kv[1]):
            print(f"        wait[{r}] = {v:.3f} ms")
        if verbose:
            for a, b, dd, m, stk in sorted(waits, key=lambda x: -x[2])[:12]:
                print(f"        W {a/1000:10.3f}->{b/1000:10.3f} {dd:7.3f}ms "
                      f"{m['reason']}\n            {fmt_stack(stk, sym) if stk else 'NO-STACK'}")
            for a, b, dd, m in sorted(readys, key=lambda x: -x[2])[:8]:
                print(f"        R {a/1000:10.3f}->{b/1000:10.3f} {dd:7.3f}ms "
                      f"readied-by {m.get('by') or '(preempted/%s)' % m.get('reason')}")
    return res


WRITE_FN_MARKERS = ("NtfsNonCached", "NtfsWaitOnIo", "NtfsCommonWrite",
                    "NtfsFsdWrite", "LfsSynchronousPageWrite",
                    "IoSynchronousPageWrite")


def write_path_addrs(run):
    """Addresses known (from the shared boot-wide symbol dictionary) to be
    part of the NTFS non-cached write / log-flush path.  Same boot => the
    same code addresses appear in every run's kernel ETL even when that
    run's dump could not be symbol-resolved."""
    out = set()
    for addr, name in run["sym"].items():
        fn = name.split("!")[-1]
        if any(k in fn for k in WRITE_FN_MARKERS):
            out.add(addr)
    return out


def is_write_wait(stk, run, addrs=None):
    if not stk:
        return False
    rendered = render_stack(stk, run["sym"])
    if any(any(k in r for k in WRITE_FN_MARKERS) for r in rendered):
        return True
    if addrs is None:
        addrs = write_path_addrs(run)
    hits = sum(1 for addr, _ in stk if int(addr, 16) in addrs)
    return hits >= 2


def write_waits(run, tid, eps_cache=None):
    """(a,b) waits whose stack shows NTFS non-cached write (the harness's
    stderr writes flush through the NTFS log file)."""
    out = []
    addrs = write_path_addrs(run)
    eps = eps_cache if eps_cache is not None else episodes(run["kd"])
    for a, b, st, meta in eps.get(tid, []):
        if b is None:
            b = run["kd"]["p_end"]
        if st != "WAITING":
            continue
        stk = find_stack(run["kd"], meta["stack_ts"], tid, tol=500)
        if is_write_wait(stk, run, addrs):
            out.append((a, b))
    return out


def merge_bursts(w, thr=600, minn=8):
    merged = []
    for a, b in w:
        if merged and a - merged[-1][1] < thr:
            merged[-1] = (merged[-1][0], b, merged[-1][2] + 1)
        else:
            merged.append((a, b, 1))
    return [(a, b, n) for a, b, n in merged if n >= minn]


def align_run(run, verbose=True):
    """Per-trace independent alignment.

    The harness's only file output is its NORMTRACE stderr stream; each
    marker line is written as several unbuffered non-cached writes whose
    NTFS log-file flushes are visible as waits in the kernel trace.  The
    first such burst is W(E00) (the program's first write); the E-series
    chain then predicts the write-start of E11/E21/E131, which must land
    on later burst starts (or inside a merged burst).  The residuals
    across those independent anchors are the alignment uncertainty.
    """
    kd = run["kd"]
    mt = main_thread_tid(kd)
    eps = episodes(kd)
    bs = merge_bursts(write_waits(run, mt, eps))
    m = run["markers"]
    if not bs or "E00_MAIN_ENTRY" not in m:
        return None
    A = bs[0][0] / 1000.0 - m["E00_MAIN_ENTRY"][0] / 1000.0
    anchors = {}
    for key in ("E11_EVENT_LOOP_READY", "E21_WINDOW_CREATE_END",
                "E131_REDRAW_CALLBACK"):
        if key not in m:
            continue
        pred = (A * 1000.0) + m[key][0]
        best = min(bs, key=lambda x: abs(x[0] - pred))
        resid = (best[0] - pred) / 1000.0
        inside = best[0] - 600 <= pred <= best[1]
        anchors[key] = {"resid_ms": resid, "inside_burst": inside}
    real = [v["resid_ms"] for v in anchors.values()]
    if verbose:
        print(f"   align {run['run']}: A={A:.3f}ms bursts={len(bs)} " +
              ", ".join(f"{k.split('_')[0]}:{v['resid_ms']:+.3f}ms"
                        f"{'*merged' if v['inside_burst'] else ''}"
                        for k, v in anchors.items()))
    return {"A": A, "bursts": bs, "anchors": anchors,
            "spread_ms": (max(real) - min(real)) if real else None}


def batch(args):
    runs = []
    for spec in args.runs.split(","):
        r, p = spec.split(":")
        runs.append((r, int(p)))
    out = []
    for r, pid in runs:
        print(f"== batch {r} pid={pid}")
        run = load_run(args.probe, args.logs, args.rd, r, pid,
                       kdump=args.kdump)
        al = align_run(run)
        entry = {"run": r, "pid": pid,
                 "p_start": run["kd"]["p_start"], "p_end": run["kd"]["p_end"],
                 "markers": {k: v[0] for k, v in run["markers"].items()},
                 "align": ({"A": al["A"], "anchors": al["anchors"],
                            "spread_ms": al["spread_ms"],
                            "bursts": al["bursts"]} if al else None),
                 "windows": []}
        if al:
            for w in args.win:
                d = decompose(run, al["A"], w, verbose=args.verbose)
                if d:
                    entry["windows"].append(d)
        out.append(entry)
    if args.out:
        Path(args.out).write_text(json.dumps(out, indent=1))
        print(f"wrote {args.out} ({len(out)} runs)")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("timeline", "windows", "json", "batch"):
        p = sub.add_parser(name)
        p.add_argument("--run", default=None)
        p.add_argument("--pid", type=int, default=None)
        p.add_argument("--runs", default=None,
                       help="batch mode: run:pid,run:pid,...")
        p.add_argument("--probe", required=True)
        p.add_argument("--logs", required=True)
        p.add_argument("--rd", default="")
        p.add_argument("--kdump", default=None)
        p.add_argument("--e00-kms", type=float, default=None)
        p.add_argument("--win", action="append", default=[])
        p.add_argument("--thread", type=int, default=None)
        p.add_argument("--verbose", action="store_true")
        p.add_argument("--out", default=None)
    args = ap.parse_args()

    if args.cmd == "batch":
        batch(args)
        return

    run = load_run(args.probe, args.logs, args.rd, args.run, args.pid,
                   kdump=args.kdump)
    print(f"== {args.run} pid={args.pid} "
          f"p_start={run['kd']['p_start']} p_end={run['kd']['p_end']} "
          f"delta={run['delta']}")
    print(f"   cswitch(child-involving)={len(run['kd']['cswitch'])} "
          f"ready={len(run['kd']['readythread'])} "
          f"stacks={len(run['kd']['stacks'])} "
          f"t_start={sorted(run['kd']['t_start'].items())}")
    print(f"   user-ETL child events={len(run['uev'])} {run['provs']}")
    if run["kk"]["first_ready_abs"] is not None and run["kd"]["readythread"]:
        d2 = run["kk"]["first_ready_abs"] - run["kd"]["readythread"][0]["ts"]
        print(f"   delta cross-check (first ReadyThread): {d2:.1f} "
              f"(diff {d2 - (run['delta'] or 0):.1f} us)")

    if args.cmd == "timeline":
        print_timeline(run, args.e00_kms, with_stacks=args.verbose)
    elif args.cmd == "windows":
        res = []
        for w in args.win:
            r = decompose(run, args.e00_kms, w,
                          tids=[args.thread] if args.thread else None,
                          verbose=args.verbose)
            if r:
                res.append(r)
        if args.out:
            Path(args.out).write_text(json.dumps(res, indent=1))
            print(f"   wrote {args.out}")
    elif args.cmd == "json":
        out = {"run": args.run, "pid": args.pid,
               "p_start": run["kd"]["p_start"], "p_end": run["kd"]["p_end"],
               "markers": {k: v[0] for k, v in run["markers"].items()},
               "t_start": {str(k): v for k, v in run["kd"]["t_start"].items()},
               "t_end": {str(k): v for k, v in run["kd"]["t_end"].items()},
               "images": [(ts, Path(n).name) for ts, n in run["kd"]["image_load"]],
               "delta": run["delta"],
               "uev": [[(a - (run["delta"] or 0)) / 1000.0, p, i, o]
                       for a, p, i, o in run["uev"]]}
        Path(args.out).write_text(json.dumps(out, indent=1))
        print(f"   wrote {args.out}")


if __name__ == "__main__":
    main()
