# WINDOWS-STARTUP-ETW-ELEVATED-CLOSEOUT-1 — self-contained elevated ETW capture (v3).
#
# Purpose: collect the kernel scheduler evidence (CSwitch + ReadyThread +
# CPU Profile sampling, process/thread lifetime, image load, wait stacks)
# for the elevated rerun of WINDOWS-STARTUP-ETW-REALITY-AUDIT-1.
# Observation only: no production code; only PVAudit* ETW sessions touched.
#
# Owner interaction: at most ONE UAC approval. Everything else unattended.
# Outputs + ELEVATED-RUN-DONE.json under <OutRoot>\<timestamp>\ (+ a copy
# at <OutRoot>\ELEVATED-RUN-DONE.json).
#
# v3 CHANGES (all evidence-driven, from the first elevated attempt
# 20260914-115153 and subsequent non-elevated forensics):
#   * `xperf -start <name> -on <kernel-group>` fails 0x3ec ERROR_INVALID_FLAGS
#     (named user-type logger rejected kernel flags) AND the classic kernel
#     logger "NT Kernel Logger" is OCCUPIED by a resident Windows session
#     (`logman query -ets` shows it running), so plain `xperf -on` fails 0xb7.
#     => kernel capture MUST go through WPR system loggers (WPR does create
#     them successfully on this machine even with the resident
#     "WPR_initiated_DiagTrackMiniLogger_WPR System Collector" present).
#   * The built-in WPR "CPU" profile trace (canary-wpr.etl, 334 MB) contains
#     CSwitch + ReadyThread data (198,664 CSwitch rows in the 0-4 s window;
#     wait stacks as "Stack" rows following each CSwitch row) but ZERO
#     SampledProfile data and it records a lot of unrelated providers.
#     => use a custom .wprp (tooling\pv-etw-audit.wprp) with explicit
#     keywords/stacks copied from the validated GPUView profile.
#   * Canary validation now uses a dumper window (real data rows for
#     CSwitch/ReadyThread/SampledProfile) instead of tracerpt name grep
#     (tracerpt naming was unreliable; and the previous whole-trace window
#     choice landed in a region with no CSwitch data).
#   * Native stderr must not trip $ErrorActionPreference=Stop (PS 5.1
#     pipeline quirk observed in the transcript): all native calls go
#     through Invoke-Native (EAP=Continue + explicit exit-code check).
#   * wpr -stop gains -skipPdbGen (first canary spent ~3 min generating
#     NGEN PDBs).
#
# Validated token sources (installed help, archived under tooling/):
#   xperf -help start / -help stop / -help stackwalk / -providers KG;
#   wpr -help start / -help stop (10.0.26100.7705);
#   keyword/stack vocabulary from
#   "Windows Performance Toolkit\gpuview\log.wprp" (SystemProvider_NormalVerbose).
#
# Usage (elevated):
#   powershell -NoProfile -ExecutionPolicy Bypass -File win-etw-elevated-rerun.ps1
# Non-elevated path/env dry check:
#   ... -SelfTest

param(
    [string]$OutRoot = "C:\Users\fred1\source\PicoView-win-etw\evidence\tmp\windows-startup-etw-1\elevated",
    [int]$ArmACount = 5,
    [int]$ArmBCount = 5,
    [int]$PerRunTimeoutSec = 120,
    [switch]$SelfTest
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0

$WPT        = "C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit"
$Xperf      = Join-Path $WPT "xperf.exe"
$Wpr        = Join-Path $WPT "wpr.exe"
$Wprp       = "C:\Users\fred1\source\PicoView-win-etw\evidence\tmp\windows-startup-etw-1\tooling\pv-etw-audit.wprp"
$BinDir     = "C:\Users\fred1\source\pocketjs-win-etw\target-win-etw\release"
$DistDir    = "C:\Users\fred1\source\PicoView\evidence\tmp\cross-os-norm-1\dist-winref"
$PvWorktree = "C:\Users\fred1\source\PicoView-win-etw"
$PjWorktree = "C:\Users\fred1\source\pocketjs-win-etw"

$KernelSession = "PVAuditKernel"      # xperf named-session attempts (record only)
$UserSession   = "PVAuditUser"        # private EventTracingManagement session (anchors)
$WprSession    = "PVAuditWPR"         # WPR instance name (kernel capture)

$ProviderGuids = @(
    '{CA11C036-0102-4A2D-A6AD-F03CFED5D3C9}', # DXGI
    '{5D8087DD-3A9B-4F56-90DF-49196CDC4F11}', # Direct3D12
    '{2D4EBCA6-EA64-453F-A292-AE2EA0EE513B}', # Direct3DShaderCache
    '{9E9BBA3C-2E38-40CB-99F4-9E8281425164}', # Dwm-Core
    '{8C416C79-D49B-4F01-A467-E56D3AA8234C}', # Win32k
    '{802EC45A-1E99-4B83-9920-87C98277BA9D}'  # DxgKrnl
)
$KwAll = [UInt64]::MaxValue

function Say([string]$m) { Write-Output ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $m) }

function Invoke-Native([string]$exe, [string[]]$argv) {
    $old = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $out = & $exe @argv 2>&1
    $rc = $LASTEXITCODE
    $ErrorActionPreference = $old
    return [pscustomobject]@{ rc = $rc; out = ($out | ForEach-Object { [string]$_ }) }
}

function Test-CargoBusy {
    $busy = Get-Process -Name cargo, rustc -ErrorAction SilentlyContinue
    return [bool]$busy
}

function Test-SessionRunning([string]$namePart) {
    $r = Invoke-Native "logman.exe" @("query", "-ets")
    foreach ($line in $r.out) { if ($line -match [regex]::Escape($namePart)) { return $true } }
    return $false
}

function Start-UserSessionPrivate([string]$etlPath) {
    Remove-EtwTraceSession -Name $UserSession -ErrorAction SilentlyContinue
    New-EtwTraceSession -Name $UserSession -LocalFilePath $etlPath | Out-Null
    foreach ($g in $ProviderGuids) {
        Add-EtwTraceProvider -SessionName $UserSession -Guid $g -Level 0xff -MatchAnyKeyword $KwAll -ErrorAction Stop | Out-Null
    }
}

function Stop-UserSessionPrivate {
    Remove-EtwTraceSession -Name $UserSession -ErrorAction SilentlyContinue
}

function Start-KernelCapture([string]$strategy, [string]$etlPath) {
    if ($strategy -eq "wpr-custom") {
        $r = Invoke-Native $Wpr @("-start", "$Wprp!PVAuditKernel", "-filemode", "-instancename", $WprSession)
        if ($r.rc -ne 0) { throw ("WPR_CUSTOM_START_FAILED rc=" + $r.rc + " out=" + ($r.out -join " / ")) }
        return
    }
    if ($strategy -eq "wpr-custom-nostacks") {
        $r = Invoke-Native $Wpr @("-start", "$Wprp!PVAuditKernelNoStacks", "-filemode", "-instancename", $WprSession)
        if ($r.rc -ne 0) { throw ("WPR_NOSTACKS_START_FAILED rc=" + $r.rc + " out=" + ($r.out -join " / ")) }
        return
    }
    throw ("UNKNOWN_STRATEGY " + $strategy)
}

function Stop-KernelCapture([string]$strategy, [string]$etlPath) {
    $r = Invoke-Native $Wpr @("-stop", $etlPath, "PicoView elevated ETW audit", "-instancename", $WprSession, "-skipPdbGen")
    return $r
}

# Mechanical per-ETL check: dump a small window and count REAL data rows
# (never assume an exit code means data). Returns counts + rc details.
function Test-KernelEtlWindow([string]$etlPath, [int]$lo, [int]$hi) {
    $dump = $etlPath + ".check.csv"
    $r = [ordered]@{ etl = $etlPath; lo = $lo; hi = $hi; bytes = 0; cswitch = 0; readythread = 0; sampled = 0; dump_rc = $null; ok = $false; error = "" }
    try {
        if (-not (Test-Path $etlPath)) { $r.error = "ETL_MISSING"; return $r }
        $r.bytes = (Get-Item $etlPath).Length
        $d = Invoke-Native $Xperf @("-i", $etlPath, "-o", $dump, "-quiet", "-a", "dumper", "-range", "$lo", "$hi")
        $r.dump_rc = $d.rc
        if (-not (Test-Path $dump)) { $r.error = "DUMP_NO_CSV rc=" + $d.rc + " " + ($d.out -join " / "); return $r }
        $r.cswitch     = (Select-String -Path $dump -Pattern "^ *CSwitch, *[0-9]" | Measure-Object).Count
        $r.readythread = (Select-String -Path $dump -Pattern "^ *ReadyThread, *[0-9]" | Measure-Object).Count
        $r.sampled     = (Select-String -Path $dump -Pattern "^ *SampledProfile, *[0-9]" | Measure-Object).Count
        $r.ok = ($r.cswitch -gt 0)
    } catch {
        $r.error = $_.Exception.Message
    } finally {
        if (Test-Path $dump) { Remove-Item $dump -Force -ErrorAction SilentlyContinue }
    }
    return $r
}

function Get-AmbientCpu {
    $samples = @()
    try {
        $samples = (Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 3 -ErrorAction Stop).CounterSamples.CookedValue
    } catch {
        return @{ avg = $null; max = $null; error = $_.Exception.Message }
    }
    return @{ avg = [math]::Round(($samples | Measure-Object -Average).Average, 2);
              max = [math]::Round(($samples | Measure-Object -Maximum).Maximum, 2) }
}

# ---------------------------------------------------------------- pre-flight
if (-not (Test-Path $Xperf))  { throw "XPERF_MISSING $Xperf" }
if (-not (Test-Path $Wpr))    { throw "WPR_MISSING $Wpr" }
if (-not (Test-Path $Wprp))   { throw "WPRP_MISSING $Wprp" }
if (-not (Test-Path (Join-Path $BinDir "examples\norm-a.exe"))) { throw "NORM_A_MISSING" }
if (-not (Test-Path (Join-Path $BinDir "examples\norm-b.exe"))) { throw "NORM_B_MISSING" }
if (-not (Test-Path (Join-Path $DistDir "picoview-a6-main.js"))) { throw "DIST_MISSING" }

if ($SelfTest) {
    Say "SELFTEST paths OK"
    Say ("  xperf  = " + $Xperf + "  " + (Get-Item $Xperf).VersionInfo.FileVersion)
    Say ("  wpr    = " + $Wpr + "  " + (Get-Item $Wpr).VersionInfo.FileVersion)
    Say ("  wprp   = " + $Wprp)
    [xml]$x = Get-Content $Wprp -Raw
    $names = @($x.WindowsPerformanceRecorder.Profiles.Profile | ForEach-Object { $_.Name })
    Say ("  wprp profiles = " + ($names -join ","))
    Say ("  binA   = " + (Join-Path $BinDir "examples\norm-a.exe"))
    Say ("  binB   = " + (Join-Path $BinDir "examples\norm-b.exe"))
    Say ("  outroot= " + $OutRoot)
    New-Item -ItemType Directory -Force -Path $OutRoot | Out-Null
    $t = Join-Path $OutRoot ("_selftest-{0}.tmp" -f (Get-Date -Format "HHmmss"))
    Set-Content -Path $t -Value "ok"
    Remove-Item $t -Force
    Say "SELFTEST write OK"
    exit 0
}

# elevation gate
$wid = [Security.Principal.WindowsIdentity]::GetCurrent()
$wp  = New-Object Security.Principal.WindowsPrincipal($wid)
$elevated = $wp.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$integrity = ($wid.Groups | Where-Object { $_.Value -like "S-1-16-*" } | ForEach-Object { $_.Value }) -join ","
if (-not $elevated) {
    Write-Output ("NOT_ELEVATED user=" + $wid.Name + " integrity=" + $integrity)
    exit 2
}

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$root = Join-Path $OutRoot $stamp
$traceDir  = Join-Path $root "traces"
$logDir    = Join-Path $root "logs"
$canaryDir = Join-Path $root "canary"
New-Item -ItemType Directory -Force -Path $traceDir, $logDir, $canaryDir | Out-Null
Start-Transcript -Path (Join-Path $root "elevated-transcript.log") -Force | Out-Null

$runs = @()
$strategy = ""
$battery = @()
$preflightRecord = [ordered]@{}

try {
    Say "ELEVATED RUN START root=$root user=$($wid.Name) integrity=$integrity"

    # ------- environment / identity record (Phase 2C)
    $idLines = @()
    $idLines += "whoami=" + (& whoami)
    $idLines += "integrity=" + $integrity
    $idLines += "elevated=" + $elevated
    $v = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $idLines += "os=" + $v.ProductName + " build=" + $v.CurrentBuild + "." + $v.UBR + " display=" + $v.DisplayVersion
    $idLines += "hypervisor_present=" + (Get-CimInstance Win32_ComputerSystem).HypervisorPresent
    $idLines += "power_plan=" + ((powercfg /getactivescheme) -join " ")
    $idLines += "cpu=" + (Get-CimInstance Win32_Processor).Name
    $gpuNames = ((Get-CimInstance Win32_VideoController) | ForEach-Object { $_.Name } | Select-Object -First 3) -join "; "
    $idLines += "gpu=" + $gpuNames
    $idLines += "wpt_xperf=" + (Get-Item $Xperf).VersionInfo.FileVersion
    $idLines += "wpt_wpr=" + (Get-Item $Wpr).VersionInfo.FileVersion
    $idLines += "wpt_wpa=" + (Get-Item (Join-Path $WPT "wpa.exe")).VersionInfo.FileVersion
    try { $idLines += "pico_head=" + (& git -C $PvWorktree rev-parse HEAD) } catch { $idLines += "pico_head=UNAVAILABLE" }
    try { $idLines += "pico_branch=" + (& git -C $PvWorktree rev-parse --abbrev-ref HEAD) } catch { }
    try { $idLines += "pocketjs_head=" + (& git -C $PjWorktree rev-parse HEAD) } catch { $idLines += "pocketjs_head=UNAVAILABLE" }
    try { $idLines += "pocketjs_branch=" + (& git -C $PjWorktree rev-parse --abbrev-ref HEAD) } catch { }
    $free = (Get-PSDrive C).Free
    $idLines += ("disk_free_gb=" + [math]::Round($free / 1GB, 2))
    $idLines += "wprp=" + $Wprp
    $idLines += ("wprp_sha256=" + (Get-FileHash $Wprp -Algorithm SHA256).Hash)
    $idLines += "user_session=$UserSession wpr_instance=$WprSession"
    & logman query -ets 2>&1 | Set-Content -Path (Join-Path $root "resident-sessions-before.txt")
    $idLines += "resident_sessions_before=" + ((Get-Content (Join-Path $root "resident-sessions-before.txt")) | Measure-Object).Count
    Set-Content -Path (Join-Path $root "env-record.txt") -Value $idLines
    $idLines | ForEach-Object { Say ("  " + $_) }

    # ------- busy gate (Phase 3): wait out build activity, never kill.
    $waited = 0
    while ((Test-CargoBusy) -and $waited -lt 300) { Say "busy cargo/rustc; waiting"; Start-Sleep -Seconds 10; $waited += 10 }
    Say ("busy_wait_seconds=" + $waited)

    $amb0 = Get-AmbientCpu
    Say ("ambient_cpu_before avg=" + $amb0.avg + " max=" + $amb0.max)

    $env:NORMTRACE = "1"
    $env:POCKET_GPU_BACKEND = "DX12"
    $env:POCKET_FORCE_SCALE = "1.0"
    $env:POCKETJS_DIST = $DistDir
    Remove-Item Env:ETW_AUDIT_SKIP_LUID -ErrorAction SilentlyContinue

    $binA = Join-Path $BinDir "examples\norm-a.exe"
    $binB = Join-Path $BinDir "examples\norm-b.exe"

    # ---------------------------------------------------------- strategy battery
    # S1: xperf classic kernel logger (no name) — expected 0xb7 (NT Kernel
    #     Logger is resident). Recorded for the audit trail.
    Say "BATTERY S1: xperf classic kernel logger (expect 0xb7, resident)"
    $s1Etl = Join-Path $canaryDir "canary-s1-xperf-classic.etl"
    $s1 = [ordered]@{ id = "S1-xperf-classic"; rc = $null; out = ""; cswitch = $null; valid = $false }
    $s1r = Invoke-Native $Xperf @("-start", "-on", "Latency", "-stackwalk", "CSwitch+ReadyThread+Profile", "-f", $s1Etl)
    $s1.rc = $s1r.rc; $s1.out = (($s1r.out | Select-Object -First 4) -join " / ")
    if ($s1.rc -eq 0) {
        Start-Sleep -Seconds 2
        [void](Invoke-Native $Xperf @("-stop"))
        $chk = Test-KernelEtlWindow $s1Etl 300000 600000
        $s1.cswitch = $chk.cswitch; $s1.valid = [bool]$chk.ok
    }
    Say ("BATTERY S1 rc=" + $s1.rc + " cswitch=" + $s1.cswitch + " out=" + $s1.out)
    $battery += $s1

    # S2: xperf named kernel session — expected 0x3ec (observed 1st run). Record.
    Say "BATTERY S2: xperf named session (expect 0x3ec from first attempt)"
    $s2Etl = Join-Path $canaryDir "canary-s2-xperf-named.etl"
    $s2 = [ordered]@{ id = "S2-xperf-named"; rc = $null; out = ""; cswitch = $null; valid = $false }
    $s2r = Invoke-Native $Xperf @("-start", $KernelSession, "-on", "Latency", "-stackwalk", "CSwitch+ReadyThread+Profile", "-f", $s2Etl)
    $s2.rc = $s2r.rc; $s2.out = (($s2r.out | Select-Object -First 4) -join " / ")
    if ($s2.rc -eq 0) {
        Start-Sleep -Seconds 2
        [void](Invoke-Native $Xperf @("-stop", $KernelSession))
        $chk = Test-KernelEtlWindow $s2Etl 300000 600000
        $s2.cswitch = $chk.cswitch; $s2.valid = [bool]$chk.ok
    }
    Say ("BATTERY S2 rc=" + $s2.rc + " cswitch=" + $s2.cswitch + " out=" + $s2.out)
    $battery += $s2

    # S3: custom WPR profile (primary candidate).
    Say "BATTERY S3: WPR custom profile"
    $s3Etl = Join-Path $canaryDir "canary-s3-wpr-custom.etl"
    $s3 = [ordered]@{ id = "S3-wpr-custom"; rc = $null; out = ""; cswitch = $null; readythread = $null; sampled = $null; valid = $false }
    try {
        Start-KernelCapture "wpr-custom" $s3Etl
        Start-Sleep -Seconds 2
        $st = Stop-KernelCapture "wpr-custom" $s3Etl
        $s3.rc = $st.rc; $s3.out = (($st.out | Select-Object -First 4) -join " / ")
        $chk = Test-KernelEtlWindow $s3Etl 300000 900000
        $s3.cswitch = $chk.cswitch; $s3.readythread = $chk.readythread; $s3.sampled = $chk.sampled
        $s3.valid = [bool]$chk.ok
        if (-not $chk.ok) { $s3.out = (($s3.out + " | " + $chk.error) -join "") }
    } catch {
        $s3.out = $_.Exception.Message
    }
    Say ("BATTERY S3 rc=" + $s3.rc + " cswitch=" + $s3.cswitch + " readythread=" + $s3.readythread + " sampled=" + $s3.sampled + " out=" + $s3.out)
    $battery += $s3

    if ($s3.valid) {
        $strategy = "wpr-custom"
    } else {
        # S4: same profile without the Stacks block (belt-and-braces).
        Say "BATTERY S4: WPR custom profile without stacks"
        $s4Etl = Join-Path $canaryDir "canary-s4-wpr-nostacks.etl"
        $s4 = [ordered]@{ id = "S4-wpr-custom-nostacks"; rc = $null; out = ""; cswitch = $null; readythread = $null; sampled = $null; valid = $false }
        try {
            Start-KernelCapture "wpr-custom-nostacks" $s4Etl
            Start-Sleep -Seconds 2
            $st = Stop-KernelCapture "wpr-custom-nostacks" $s4Etl
            $s4.rc = $st.rc; $s4.out = (($st.out | Select-Object -First 4) -join " / ")
            $chk = Test-KernelEtlWindow $s4Etl 300000 900000
            $s4.cswitch = $chk.cswitch; $s4.readythread = $chk.readythread; $s4.sampled = $chk.sampled
            $s4.valid = [bool]$chk.ok
        } catch {
            $s4.out = $_.Exception.Message
        }
        Say ("BATTERY S4 rc=" + $s4.rc + " cswitch=" + $s4.cswitch + " out=" + $s4.out)
        $battery += $s4
        if ($s4.valid) { $strategy = "wpr-custom-nostacks" }
    }

    # always stop any leftover instance defensively (only our instance name)
    $cancel = Invoke-Native $Wpr @("-cancel", "-instancename", $WprSession)
    Say ("cleanup cancel rc=" + $cancel.rc)

    if ($strategy -eq "") {
        Say "BATTERY: no viable kernel capture strategy — writing FAIL marker"
        $doneFail = [ordered]@{
            status = "FAIL"; timestamp = (Get-Date -Format o); root = $root
            reason = "NO_KERNEL_STRATEGY_VALID"; battery = $battery
        }
        $doneFail | ConvertTo-Json -Depth 8 | Set-Content -Path (Join-Path $root "ELEVATED-RUN-DONE.json") -Encoding UTF8
        Copy-Item (Join-Path $root "ELEVATED-RUN-DONE.json") (Join-Path $OutRoot "ELEVATED-RUN-DONE.json") -Force
        Say "DONE(FAIL) written"
        exit 0
    }
    Say ("STRATEGY SELECTED: " + $strategy)

    # ---------------------------------------------------------------- series
    $series = @()
    for ($i = 0; $i -lt [math]::Max($ArmACount, $ArmBCount); $i++) {
        if ($i -lt $ArmACount) { $series += "A$i" }
        if ($i -lt $ArmBCount) { $series += "B$i" }
    }
    Say ("SERIES order=" + ($series -join ","))

    foreach ($runId in $series) {
        $arm = $runId.Substring(0, 1)
        $exe = $binA
        if ($arm -eq "B") { $exe = $binB }
        $kEtl = Join-Path $traceDir "$runId-kernel.etl"
        $uEtl = Join-Path $traceDir "$runId-user.etl"
        $log = Join-Path $logDir "$runId.log"
        $out = Join-Path $logDir "$runId.out"

        $rec = [ordered]@{
            run = $runId; arm = $arm; exe = $exe
            kernel_etl = $kEtl; user_etl = $uEtl; log = $log
            pid = $null; exitcode = $null; wall_ms = $null
            timeout = $false; valid = $false; error = ""
            kernel_bytes = 0; user_bytes = 0
            start_utc = ""; end_utc = ""
            check_cswitch = $null; check_readythread = $null; check_sampled = $null
        }

        $waited = 0
        while ((Test-CargoBusy) -and $waited -lt 120) { Start-Sleep -Seconds 5; $waited += 5 }

        $env:NORMTRACE_RUN = $runId
        try {
            Start-KernelCapture $strategy $kEtl
            Start-UserSessionPrivate $uEtl
            Start-Sleep -Milliseconds 400

            $rec.start_utc = (Get-Date).ToUniversalTime().ToString("o")
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            $p = Start-Process -FilePath $exe -RedirectStandardError $log -RedirectStandardOutput $out -PassThru -WorkingDirectory $BinDir
            $exited = $p.WaitForExit($PerRunTimeoutSec * 1000)
            $sw.Stop()
            $rec.wall_ms = $sw.ElapsedMilliseconds
            $rec.pid = $p.Id
            if (-not $exited) {
                $rec.timeout = $true
                try { $p.Kill() } catch { }
                try { $p.WaitForExit(10000) | Out-Null } catch { }
            }
            try { $rec.exitcode = $p.ExitCode } catch { $rec.exitcode = $null }
            $rec.end_utc = (Get-Date).ToUniversalTime().ToString("o")
        } catch {
            $rec.error = $_.Exception.Message
            Say ("run " + $runId + " ERROR: " + $rec.error)
        } finally {
            try { [void](Stop-KernelCapture $strategy $kEtl) } catch { }
            try { Stop-UserSessionPrivate } catch { }
        }

        Start-Sleep -Milliseconds 400

        if (Test-Path $kEtl) { $rec.kernel_bytes = (Get-Item $kEtl).Length }
        if (Test-Path $uEtl) { $rec.user_bytes = (Get-Item $uEtl).Length }
        $hasE00 = $false
        if (Test-Path $log) { $hasE00 = [bool](Select-String -Path $log -Pattern "E00_MAIN_ENTRY" -SimpleMatch -Quiet) }

        # per-run mechanical kernel check (small window, real data rows)
        if ($rec.kernel_bytes -gt 1000000) {
            $kchk = Test-KernelEtlWindow $kEtl 200000 400000
            $rec.check_cswitch = $kchk.cswitch; $rec.check_readythread = $kchk.readythread; $rec.check_sampled = $kchk.sampled
        }

        if ($rec.error -eq "" -and (-not $rec.timeout) -and $hasE00 -and $rec.kernel_bytes -gt 1000000 -and $rec.user_bytes -gt 100000 -and ($rec.check_cswitch -ne $null) -and ($rec.check_cswitch -gt 0)) {
            $rec.valid = $true
        } elseif ($rec.error -eq "" -and (-not $rec.timeout) -and (-not $hasE00)) {
            $rec.error = "E00_MARKER_MISSING_IN_LOG"
        } elseif ($rec.error -eq "" -and $rec.kernel_bytes -le 1000000) {
            $rec.error = "KERNEL_ETL_TOO_SMALL"
        } elseif ($rec.error -eq "" -and $rec.user_bytes -le 100000) {
            $rec.error = "USER_ETL_TOO_SMALL"
        } elseif ($rec.error -eq "" -and ($rec.check_cswitch -eq 0)) {
            $rec.error = "KERNEL_WINDOW_NO_CSWITCH_DATA"
        }
        Say ("run " + $runId + " valid=" + $rec.valid + " pid=" + $rec.pid + " wall=" + $rec.wall_ms + "ms kernel=" + [math]::Round($rec.kernel_bytes/1MB,1) + "MB cswitch=" + $rec.check_cswitch + " sampled=" + $rec.check_sampled + " err=" + $rec.error)
        $runs += $rec
    }

    $amb1 = Get-AmbientCpu
    Say ("ambient_cpu_after avg=" + $amb1.avg + " max=" + $amb1.max)

    # ------------------------------------------------------- cleanup check
    [void](Invoke-Native $Wpr @("-cancel", "-instancename", $WprSession))
    try { Stop-UserSessionPrivate } catch { }
    try { [void](Invoke-Native $Xperf @("-stop", $KernelSession)) } catch { }
    & logman query -ets 2>&1 | Set-Content -Path (Join-Path $root "resident-sessions-after.txt")
    $ourSessionsLeft = @(Select-String -Path (Join-Path $root "resident-sessions-after.txt") -Pattern "PVAudit" -SimpleMatch -ErrorAction SilentlyContinue)
    $cleanupOk = ($ourSessionsLeft.Count -eq 0)

    $validA = @($runs | Where-Object { $_.arm -eq "A" -and $_.valid }).Count
    $validB = @($runs | Where-Object { $_.arm -eq "B" -and $_.valid }).Count
    $status = "FAIL"
    if ($validA -ge 3 -and $validB -ge 3) { $status = "PASS" }
    elseif ($validA -ge 1 -and $validB -ge 1) { $status = "PARTIAL" }

    $failures = @($runs | Where-Object { -not $_.valid } | ForEach-Object { $_.run + ":" + $_.error })

    $done = [ordered]@{
        status = $status
        timestamp = (Get-Date -Format o)
        root = $root
        elevated = $elevated
        integrity = $integrity
        strategy = $strategy
        battery = $battery
        armA_requested = $ArmACount; armB_requested = $ArmBCount
        armA_valid = $validA; armB_valid = $validB
        ambient_cpu_before = $amb0; ambient_cpu_after = $amb1
        runs = $runs
        failures = $failures
        cleanup_ok = $cleanupOk
        our_sessions_left = @($ourSessionsLeft | ForEach-Object { $_.Line })
    }
    $done | ConvertTo-Json -Depth 8 | Set-Content -Path (Join-Path $root "ELEVATED-RUN-DONE.json") -Encoding UTF8
    Copy-Item (Join-Path $root "ELEVATED-RUN-DONE.json") (Join-Path $OutRoot "ELEVATED-RUN-DONE.json") -Force
    Say ("DONE(" + $status + ") strategy=" + $strategy + " armA=" + $validA + " armB=" + $validB + " cleanup_ok=" + $cleanupOk)
} catch {
    Say ("FATAL: " + $_.Exception.Message)
    try {
        $doneFatal = [ordered]@{ status = "FAIL"; timestamp = (Get-Date -Format o); root = $root; reason = $_.Exception.Message; battery = $battery; runs = $runs }
        $doneFatal | ConvertTo-Json -Depth 8 | Set-Content -Path (Join-Path $root "ELEVATED-RUN-DONE.json") -Encoding UTF8
        Copy-Item (Join-Path $root "ELEVATED-RUN-DONE.json") (Join-Path $OutRoot "ELEVATED-RUN-DONE.json") -Force
    } catch { }
    try { [void](Invoke-Native $Wpr @("-cancel", "-instancename", $WprSession)) } catch { }
    try { Stop-UserSessionPrivate } catch { }
    try { [void](Invoke-Native $Xperf @("-stop", $KernelSession)) } catch { }
    exit 5
} finally {
    try { Stop-Transcript | Out-Null } catch { }
}
