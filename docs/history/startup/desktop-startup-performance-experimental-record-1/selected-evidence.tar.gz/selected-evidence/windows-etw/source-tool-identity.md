# WINDOWS-STARTUP-ETW-REALITY-AUDIT-1 — source & tool identity

Recorded 2026-09-14 (local). Companion to
`docs/WINDOWS-STARTUP-ETW-REALITY-AUDIT-1.md`.

## Source identity

### PicoView (audit worktree, isolated)

- path: `C:\Users\fred1\source\PicoView-win-etw`
- branch: `audit/windows-startup-etw-1`, base SHA `491d0a5` (= main, same
  content as the prior WINDOWS-STARTUP-CALLPATH-REALITY-AUDIT-1 base);
  docs-only (this report + companion files). The session worktree
  `C:\Users\fred1\source\PicoView` was used read-only (guest bundle only).

### PocketJS (audit worktree, isolated)

- path: `C:\Users\fred1\source\pocketjs-win-etw`
- branch: `audit/windows-startup-etw-1`
- BRANCH_FINAL_TIP (pre-audit base): `9a1b8d69`
  (= `4b2de0a4` + lockfile; code content identical to `4b2de0a4`)
- MEASURED_HEAD (effective, reproduces the known E-series + nested
  D3D12CreateDevice markers): `4b2de0a4` = base `e15674db` (tree f09cf9fa,
  E00–E190 instrumentation) + audit-local `2ca5dc4c` (arm-B backend
  selector), `66df576f` (vendored wgpu-hal 25.0.2 + E50a–h nested markers),
  `4b2de0a4` (AUDIT_DXGI_ADAPTER LUID lines)
- this audit added one measurement-only commit:
  `be58f53c` — env-gated `ETW_AUDIT_SKIP_LUID` exact-LUID expose skip +
  selected-LUID carry on the AdapterInfo driver string + norm-b
  BENCHMARK_CONFIG `driver` field + `/target-win-etw/` gitignore
- ETW-capture binaries: built from `9a1b8d69` + `be58f53c` content,
  `CARGO_TARGET_DIR=target-win-etw`, `CARGO_PROFILE_RELEASE_DEBUG=2`
  (release + full PDB); absolute numbers from these builds are analysis
  aids only, never headline
- BASELINE (Phase 1) binaries: the prior audit's headline binaries
  (content `2ca5dc4c`), executed read-only in place from
  `C:\Users\fred1\source\pocketjs-win-startup\target-win-startup-audit\release`
  (same artifacts that produced the published 132.1/560.9/585.8 P50 set)

### Guest artifact (unchanged, read-only)

- `C:\Users\fred1\source\PicoView\evidence\tmp\cross-os-norm-1\dist-winref`
  — `picoview-a6-main.js` 357,862 B (sha256 cf73383f1220c564181a8…) /
  `picoview-a6-main.pak` 304,944 B (sha256 3059416e4ba97e9b10f42…)

## Tool identity

| tool | identity |
|---|---|
| Windows build | Microsoft Windows [Version 10.0.26200.9445] (Pro) |
| WPR | 10.0.26100 (CoreSystem), `C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit\wpr.exe` (a System32 `wpr.exe` also exists; the WPT one is authoritative) |
| xperf/WPA | 10.0.26100, same WPT directory |
| PerfView | 3.2.6+9a99c8202310fc0ab2f84690881f6a4a4ada0c44, `C:\Users\fred1\source\PerfView.exe` |
| logman | OS build-in (26200); rejects multiple `-p` on one session ("parameter p defined too many times") |
| ETW sessions | PowerShell EventTracingManagement cmdlets (New-EtwTraceSession / Add-EtwTraceProvider / Remove-EtwTraceSession) — used for all captures |
| tracerpt | OS build-in, used for ETL→CSV event dumps |
| rustc/cargo | 1.98.1 (48a229cea 2026-09-01) / 1.98.1, host x86_64-pc-windows-msvc — unchanged campaign toolchain |
| shell privileges | NOT elevated — Medium Mandatory Level (S-1-16-8192); `net session` denied |

## Machine state (Phase 0)

- CPU: AMD Ryzen 7 5800H (8C/16T); RAM 28.9 GiB
- GPU: AMD Radeon(TM) Graphics iGPU, driver 31.0.21923.11000
  (2025-07-01, Adrenalin 25.8.1) — single PnP video adapter
- display: 1× 2560x1440 primary, system DPI 96 (1.0x scale);
  measurements used `POCKET_FORCE_SCALE=1.0`
- power plan: Balanced (381b4222-f694-41f0-9685-ff5bb260df2e)
- Hyper-V/VBS: HypervisorPresent=True; VBS
  VirtualizationBasedSecurityStatus=2 (enabled+running);
  SecurityServicesRunning={0}; HVCI Enabled=0; Hyper-V VMBus/VSP/PCI
  infrastructure PnP devices present; root\virtualization\v2 WMI not
  readable non-admin
- resident AV: 腾讯电脑管家系统防护 (QQPCRTP, productState 266240 =
  enabled) + Windows Defender (productState 393472 = disabled/snoozed;
  pre-existing state, matches prior audits)
- resident ETW load: 27+ trace sessions running, incl. kernel-mode
  `WPR_initiated_DiagTrackMiniLogger_WPR System Collector` (since
  2026-09-08) and QQPCMgr Krnl/Perf Track sessions; `xperf -on` (default
  NT Kernel Logger) fails with ERROR_ALREADY_EXISTS (0xb7)

## Privilege capability matrix (non-admin, this host, verified)

| capability | non-admin result |
|---|---|
| WPR built-in kernel profiles (`wpr -start CPU -filemode`) | DENIED — "Failed to enable the policy to profile system performance" |
| xperf kernel session | NT Kernel Logger exists (0xb7); kernel logger requires elevation regardless |
| user-mode private session + providers (cmdlets/logman single-p) | WORKS |
| Microsoft-Windows-DxgKrnl events into private session | WORKS (≈10800 events / 2 s idle; dense during real run) |
| Microsoft-Windows-Win32k | WORKS (window/GDI handle ops visible) |
| Microsoft-Windows-Dwm-Core | WORKS |
| Microsoft-Windows-DXGI | WORKS |
| Microsoft-Windows-Direct3D12 / -Direct3DShaderCache | enabled OK; idle-silent (some events during real runs) |
| Microsoft-Windows-Kernel-Process / -Kernel-File | enabled OK; NO events flow (header-only) |
| CPU sampling (Profile), CSwitch/ReadyThread, image load, file IO | NOT COLLECTABLE — requires elevation |
