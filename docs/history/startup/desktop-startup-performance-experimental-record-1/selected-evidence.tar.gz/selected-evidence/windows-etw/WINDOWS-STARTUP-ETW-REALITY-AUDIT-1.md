# WINDOWS-STARTUP-ETW-REALITY-AUDIT-1

Windows-only ETW startup audit for the PicoView / PocketJS desktop host:
E00–E190 monotonic markers remain the wall-clock authority; Windows
Performance Toolkit / ETW and a non-admin user-mode private-session
capability are used to explain, at the Windows native-call-path level,
where startup time is spent. No Linux data. No production optimization.
#42/#43 untouched.

**HEADLINE DISPOSITION (updated by the elevated closeout):
`PASS_WITH_OPEN_CAUSE`.**

The elevated kernel trace ran (one UAC approval; unattended; cleanup
verified; DONE marker `ELEVATED-RUN-DONE.json` status PASS) and its kernel
evidence is valid: CSwitch + ReadyThread + stack walks + process/thread
lifetime + image loads in 5 arm A and 5 arm B traces. Q1 (`E20→E21`
window creation) and Q2 (the two AMD `D3D12CreateDevice` probe windows)
are decomposed into RUNNING / READY / WAITING with wait stacks and wake
sources from the scheduler's own records, per trace, on a measured
sub-0.1 ms clock alignment (§CLOCK ALIGNMENT). The prior
`BLOCKED — ADMIN_REQUIRED_FOR_KERNEL_TRACE` disposition is retired.

One mandated item is **not obtainable on this machine**: the
kernel-vs-user CPU split (`SampledProfile` is unavailable here under two
independent profile definitions — measured, §ELEVATED KERNEL TRACE), so
RUNNING is reported as a single state and no split is claimed. That is
the open cause. Four prior claims are corrected by the elevated data
(§CORRECTIONS TO THE NON-ELEVATED PASS). Two fresh adversarial reviewers
returned **REVISE** with no BLOCKERs; every finding they raised is fixed
in this revision (§REVIEWS). No production fix is authorized.

## SOURCE IDENTITY

| item | identity |
|---|---|
| PicoView branch/SHA | `audit/windows-startup-etw-1` @ `491d0a5` (= main; docs only) |
| PicoView worktree | `C:\Users\fred1\source\PicoView-win-etw` (isolated) |
| PocketJS worktree | `C:\Users\fred1\source\pocketjs-win-etw` (isolated) |
| PocketJS BRANCH_FINAL_TIP (pre-audit) | `9a1b8d69` (= `4b2de0a4` + lockfile) |
| PocketJS MEASURED_HEAD | `4b2de0a4` = `e15674db` + `2ca5dc4c` + `66df576f` + `4b2de0a4` (reproduces the known E-series + nested E50a–h markers) |
| PocketJS audit commit added | `be58f53c` (measurement-only exact-LUID skip + selected-LUID carry) |
| Baseline (Phase 1) binaries | prior audit's headline artifacts (content `2ca5dc4c`), executed read-only in place |
| ETW-capture binaries | `9a1b8d69`+`be58f53c` content, release + PDB (`CARGO_PROFILE_RELEASE_DEBUG=2`), `target-win-etw` |
| Guest | frozen `picoview-a6-main` bundle, js 357,862 B / pak 304,944 B (read-only from `dist-winref`) |

Details in `docs/windows-startup-etw-1/source-tool-identity.md`.

## TOOL IDENTITY

WPR / xperf / WPA 10.0.26100 (CoreSystem, Windows Kits WPT dir); PerfView
3.2.6 (`C:\Users\fred1\source\PerfView.exe`); logman 26200 (rejects
multiple `-p` per session on this build — all captures therefore used the
EventTracingManagement cmdlets); tracerpt for ETL→CSV; rustc/cargo
1.98.1. Installed help output for every tool archived under
`evidence/tmp/windows-startup-etw-1/tooling/` (`wpr-help*.txt`,
`xperf-help*.txt`, `xperf-providers-KG.txt`); no switch was used from
memory.

Elevated closeout tooling (archived, recomputable; all paths below are
under `evidence/tmp/windows-startup-etw-1/`, which is gitignored — the
raw ETLs/CSVs live there, the report and identity docs are tracked):
`tooling/win-etw-elevated-rerun.ps1` (v3 capture script, syntax and
self-test validated), `tooling/pv-etw-audit.wprp` (custom WPR system
profile), `tooling/analyze_elevated.py` (alignment + state decomposition
+ wait stacks + wakes), `tooling/check_gaps.py` (NORMTRACE gap checker),
plus the review-driven recomputers `tooling/verify_review_findings.py`
(aggregate scopes), `tooling/place_events.py` (user-ETL event placement
via the Process/Start delta), `tooling/check_stack_rule.py` (wait-stack
attribution-rule sensitivity); machine outputs
`elevated/_probe/elevated-analysis.json` /
`.log` (all 10 runs), `recheck-preempt.json` (strict preempted=READY
variant), `wpaexp-applaunch/`, `wpaexp-b1/`, `wpaexp-fast/` (wpaexporter
runs), `symcache/` (resolved PDBs), `elevated/machine-state-readback-20260914.txt`.

Reproducibility note: the analyzer's `episodes()` now implements the
strict preempted→READY rule, so re-running it yields the variant archived
as `recheck-preempt.json` (A0 `E20→E21` READY 1.975 / WAIT 21.084) —
`elevated-analysis.json` was produced with the earlier WAITING-by-default
rule (1.883 / 21.176). Both are archived; the difference is ≤0.1 ms
everywhere quoted. One latent guard (not triggered by any window in this
report): CSwitch rows continue past `P-End` (A0 has 15 such rows,
including a `WrTerminated`), so a future window extended into teardown
would need an explicit close-out rule for RUNNING intervals.

## MACHINE STATE

Windows 11 Pro build 26200.9445; Ryzen 7 5800H 8C/16T; 28.9 GiB; AMD
Radeon(TM) Graphics iGPU driver 31.0.21923.11000 (2025-07-01); 1×
2560x1440 @ DPI 96 (1.0x); Balanced power plan; **HypervisorPresent=True,
VBS running (status 2), HVCI not running, SecurityServicesRunning={0},
Hyper-V VMBus/VSP/PCI PnP infrastructure present** (read-only readback
archived: `elevated/machine-state-readback-20260914.txt`); QQPCRTP
resident (enabled), WinDefend service stopped (pre-existing); **56
resident ETW sessions at capture time, including a kernel-mode
WPR/DiagTrack system collector (since 2026-09-08) and QQPCMgr
kernel/perf trace sessions** (dump: 59 lines = 2 header + 56 session
rows + 1 status line; before/after byte-identical); shell non-elevated.

## TRACE CONFIGURATION

Bounded, one private ETW session per sample (started immediately before
process spawn, stopped after exit; per-run ETL 12–23 MiB):

- providers (all keywords, verbose level): DXGI
  {CA11C036-…}, Direct3D12 {5D8087DD-…}, Direct3DShaderCache
  {2D4EBCA6-…}, Dwm-Core {9E9BBA3C-…}, Win32k {8C416C79-…}, DxgKrnl
  {802EC45A-…}
- runner: `tooling/win-etw-capture.ps1` (v3; v1/v2 failure lessons: this
  logman build rejects repeated `-p`, and PowerShell nested-array
  splatting silently malformed the v1 invocation — v3 uses flat cmdlet
  calls and hard-verifies session/ETL/log after every step)
- per-run metadata (child PID, spawn/exit wall) in `run-*.meta`
- analysis: `tracerpt` → CSV; event decoding via provider manifests
  exported from `Get-WinEvent -ListProvider` (`tooling/*-meta.csv`);
  alignment via `tooling/align_audit.py`
- non-admin capability matrix (verified): DxgKrnl/Win32k/Dwm-Core/DXGI
  events flow into a private user session WITHOUT elevation;
  Kernel-Process/Kernel-File enable but emit nothing; CPU sampling,
  CSwitch/ReadyThread, image load, file IO are elevation-gated and were
  NOT collected

## CURRENT BASELINE (Phase 1)

Visible windows, DX12, same guest/viewport/density; prior audit's
headline binaries (content `2ca5dc4c`), ambient quiet gates honored by
the runner; n valid/invalid 10/0, 10/0, 20/0; `config_uniform` PASS all
batches.

| arm | endpoint | P50 | P95 | min | max | prior P50 |
|---|---|---|---|---|---|---|
| A winit only | E00→E199 | **91.5 ms** | 129.6 | 88.6 | 153.2 | 132.1 |
| B winit + wgpu DX12 | E00→E190 | **554.2 ms** | 850.6 | 536.1 | 859.9 | 560.9 |
| C full PocketJS | E00→E190 | **580.0 ms** | 664.0 | 567.4 | 675.0 | 585.8 |

Shape check: **A ≪ B ≈ C holds; the adapter stage remains dominant**
(arm C `E50→E51` P50 **364.6 ms** = 63% of E00→E190; `window_create`
P50 51.6 ms; `device` 42.7 ms). B and C reproduce the prior audit within
1.2%. Two honest deviations, neither material to the ETW questions:

1. arm A / `window_create` runs faster than the prior audit
   (91.5 vs 132.1 ms endpoint P50; **46.2 vs 73.8 ms** window_create own
   P50, arm A n=10 — the arm-C figure for the same stage is 51.6 ms on
   n=20). This stage is the
   host's known load-sensitive component (STARTUP-LAST-MILE-REALITY-AUDIT-1:
   cross-session variance is background-load-driven). Q1's "~70 ms"
   premise is therefore analyzed as "today ~46–53 ms clean (arm A 46.2,
   arm C 51.6), historically 68–74 ms" — same stage, same lane, same
   shape.
2. B P95 carries one ~860 ms tail outlier (P50 unaffected).

**BASELINE_DRIFT: NOT DECLARED** — the dominant path reproduces within
1%; the machine state for the ETW questions is current.

## ARM A — FIRST WINDOW (winit only; 5 traces, non-elevated session)

> **Corrected by the elevated closeout** (see §CORRECTIONS TO THE
> NON-ELEVATED PASS): the `DxgKrnl Process/Start` ↔ E20-begin bridge
> claim below is NOT supported — in all 10 elevated traces that event
> and the first `Win32k UserHandleOperation/CreateHandle` fire
> ≈3.3–4.5 ms / ≈3.1–4.2 ms **before E00**, i.e. pre-main. The
> *content* of this section's manifest observations stands; two
> *placements* do not, because they came from that bridge: the
> DxgKrnl/handle churn below is measured **inside** `E20→E21` (elevated,
> independently placed), and the CDD/redirection cluster + `Rendering`
> event sit at +27.0…+59.7 ms **inside** the window — between `E21` and
> `E130` the elevated A0 trace records zero child events. The per-run
> offsets `o` quoted below are the retired bridge's output and are not
> independently re-verifiable.

Per-run `E20→E21` **in the non-elevated session** (in-trace
instrumented build): 57.3 / 56.9 / 115.8 / 45.4 / 52.1 ms. Child-PID
ETW signature (run-000, offset o≈+301 ms — the retired bridge):

- `DxgKrnl Process/Start` (process graphics attach) fires at E20 begin
  (≤0.25 ms before the first `Win32k UserHandleOperation/CreateHandle`)
  — window creation begins with an immediate kernel process-attach +
  user-handle creation. *(Corrected: pre-main, not E20 begin.)*
- A continuous `Win32k GdiHandleOperation` storm — the non-elevated
  "1559 events over ~104 ms" figure was located by the retired bridge
  and cannot be re-derived (bounds only, that session: 3,934 such
  events over 291.9 ms). In the elevated A0 trace the equivalent is
  1,815 events over 114.8 ms whole-trace, of which 1,065 fall inside
  `E20→E21` (first at +7.1 ms) — the storm starts before `E20` and
  continues past `E21`.
- At the first-redraw region: `CddStandardAllocation`,
  `DeviceAllocation`, `GpuVirtualAddressRange` create/destroy (VAD),
  `PagingQueuePacket`, fence/sync objects, `ExtendedProfiler`, and a
  `Win32k Rendering` event — the DWM redirection-surface establishment
  for the shown window. *(Corrected placement: in the elevated trace
  this whole cluster sits at +27.0…+59.7 ms **inside** `E20→E21`
  (ending with `Win32k OldToNewRendering` at +59.6 ms); nothing follows
  until redraw, and the `DxgKrnl Process/Stop` is not here — it fires at
  +130.7 ms, after the first redraw. The elevated A0 trace shows zero
  child events between `E21` and `E130`.)*
- No single multi-tens-of-ms manifest-visible block appears inside
  `E20→E21`; the interval is covered by continuous user-handle + GDI
  churn (work, not manifest-visible waiting). *(Confirmed by the
  elevated state split: no main-thread wait >0.79 ms; the process's
  other threads do carry 24.8–78.2 ms waits — they are not the
  interval owner.)*

Bridge method (per trace): one anchor pair (`DxgKrnl Process/Start` ↔
E-series anchor event: E20 begin for arm A, E30 begin for arm B; anchors
agree within 0.1–0.25 ms with the first Win32k handle event). Rust
`Instant` and ETW share the QPC timebase, so the bridge is a constant
offset; per-run offsets (o = Process/Start − anchor): A 301.4 / 184.4 /
12.0 / 186.5 / 201.2 ms; B 199.9 / 128.4 / 128.0 / 143.9 / 126.0 ms.
Structural cross-validation is consistent on all 10 traces; single-anchor
offsets are stated as approximate, and the quoted `o` values have no
archived artifact that reproduces them (the elevated closeout replaces
this bridge with a write-burst-derived alignment validated to ≤0.10 ms
on two anchors in all 10 traces — §CLOCK ALIGNMENT).

## ARM B — DX12 ADAPTER INIT (winit + wgpu DX12; 5 traces, non-elevated session)

In-trace instrumented-build markers (ETW adds overhead; these are
analysis-aid numbers — this section's per-run lists are the
**non-elevated** session; the Q2 table further below is the elevated
one): `E50→E51` 392.8 / 352.7 / 353.2 / 402.3 / 357.8 ms
(P50 357.8); probe#0 (AMD LUID 0-e1e6) 205.0 / 167.4 / 168.4 / 179.6 /
166.2 (P50 168.4); probe#1 (AMD LUID 0-1a8f2) 141.5 / 142.6 / 141.0 /
169.2 / 145.8 (P50 142.6); MBRD ~6 ms; `device E60→E61` 40.0–71.2 ms.
`AUDIT_DXGI_ADAPTER` lines reproduce the prior audit exactly: one AMD
iGPU (vid 0x1002 pid 0x1638) exposed under two LUIDs, 0-e1e6 and 0-1a8f2,
plus Microsoft Basic Render Driver.

Child-PID kernel-side signature (run-000, o≈+200 ms — see the correction
note under ARM A about that offset):

- **The two AMD `D3D12CreateDevice` probes generate almost no
  DxgKrnl/Win32k manifest events.** Across the entire ~393 ms adapter
  span the child emits one `Profiler` start/stop pair (pre-main/early
  region) and, near probe#1's end, one dense ~0.5 s cluster
  (`QueuePacket`, `UpdateContextRunningTime`, `DmaPacket`,
  `YieldConditionEvaluation`, `DdiSetVidPnMultiPlaneOverlay3` start/stop,
  paging) — i.e. the probe cost is NOT visible as kernel scheduler/GPU-VM
  manifest work. *(The non-elevated pass then guessed "kernel-internal
  waits"; the elevated closeout **refutes the off-CPU part** of that: the
  probes are ≈97–98 % RUNNING in 9 of 10 probe windows (B0 probe#0
  95.6 %, the disclosed outlier) — on-CPU execution inside the
  D3D12/AMD user-mode + kernel driver path — with only 1.8–9.6 ms of
  sub-ms waits. User-vs-kernel mode and any on-CPU spin/poll remain
  unresolved, so no *locus* claim is made.
  §PROBE #0 / #1 THREAD-STATE BREAKDOWN.)*
- By contrast the **real** device create (`E60→E61`), surface
  configuration, and first present each leave full kernel signatures:
  device allocations, VAD create/destroy, `VidMmMakeResident` +
  `MakeResident` start/stop, `MonitoredFence`, present queue packets —
  confirming the capture/decode pipeline itself sees GPU work when it
  exists.
- `Win32k GdiHandleOperation` churn during the adapter span — the
  non-elevated "~1670 events" figure came from the retired bridge and is
  not re-derivable (bounds only, that session: 3,934 such events over
  291.9 ms). It overlaps the probe region — consistent with driver/DLL
  init (GDI-adjacent work), not with scheduler idle.

## ELEVATED KERNEL TRACE

Run: `evidence/tmp/windows-startup-etw-1/elevated/20260914-121456/`
(`ELEVATED-RUN-DONE.json`, status **PASS**; copy at `elevated/`).
Owner interaction: **exactly one UAC approval**; nothing else manual.

- **Capture route (measured, not chosen):** the classic NT Kernel Logger is
  occupied by a pre-existing resident session (`xperf -on` → 0xb7) and a
  named xperf kernel session is rejected on this build (0x3ec, invalid
  flags) — battery rows S1/S2 in the DONE marker. The working route is a
  **WPR system logger** ("WPR System Collector" in a custom profile,
  `tooling/pv-etw-audit.wprp` sha256 `3341A959…`, instance `PVAuditWPR`)
  plus a separate named user session (`PVAuditUser`) with the six graphics
  providers from the non-elevated pass. Stacks: CSwitch.
- **Validity (mechanical, per the mission's hard gate):** all 10 traces
  non-empty; CSwitch + ReadyThread present in every trace (per-run child
  CSwitch 1,401–4,172, ReadyThread 0.7k–2.0k; canary window 20,946 CSwitch /
  11,433 ReadyThread); process/thread lifetime and image-load events
  present; `logman query -ets` after the run: no `PVAudit*` sessions left
  (`cleanup_ok: true`); the 56 pre-existing resident sessions were not
  touched — the before/after session dumps are byte-identical
  (`resident-sessions-before/after.txt`, 59 lines each = 2 header + 56
  session rows + 1 status line, empty diff).
- **NOT COLLECTED — `SampledProfile`:** zero sampled-profile events under
  (a) the built-in WPR `CPU` profile canary and (b) the custom
  explicit-keyword profile; `xperf -a profile` over the canary answers
  "There is no sampled profile data in the trace". No sampling → no
  kernel/user CPU split on this machine (§KERNEL/USER CPU SPLIT below).
- **Identity:** Windows 11 Pro build 26200.9445 (25H2); AMD Ryzen 7 5800H
  iGPU; HypervisorPresent=True (unchanged, no configuration touched);
  Balanced power plan; WPT xperf/wpr 10.0.26100.7705, WPA 11.7.395.48728;
  whoami `hu\fred1` (elevated: True); PicoView `d985708` (branch
  `audit/windows-startup-etw-1`), PocketJS `be58f53c`; ambient CPU
  before/after the capture (22.84/31.58 % → 2.21/2.51 %).

## CLOCK ALIGNMENT (per trace, independent, multi-anchor)

No cross-run offset is used: every trace is aligned on its own evidence.
The harness's only file output is its NORMTRACE stderr stream; each marker
line is emitted as multiple unbuffered writes to the runner's redirected
(non-cached) stderr handle (measured: ~25–30 NTFS I/O waits per marker
line), and each write appears in the kernel trace as an NTFS non-cached
write / `$LogFile` synchronous flush wait
(`NtfsWaitOnIo ← NtfsNonCachedIo ← NtfsNonCachedUsaWrite ← … ←
LfsSynchronousPageWrite`). The first such burst is W(E00) (the program's
first write); the E-series chain then predicts W(E11), W(E21), W(E131),
which must land on later burst starts. Alignment: `kernel_ms = A +
E_us/1000` (origin = E00's `Instant` at `us=0`).

| run | A (ms) | anchors (residual of the predicted write burst, ms) |
|---|---|---|
| A0 | 1753.482 | E11 −0.031, E21 −0.045, E131 −14.684 (inside a merged burst) |
| A1 | 1198.735 | E11 −0.026, E21 −0.000, E131 +11.670 (not a burst start) |
| A2 | 1204.890 | E11 −0.062, E21 −0.064, **E131 −0.096** |
| A3 | 1182.696 | E11 −0.009, E21 −0.050, **E131 −0.046** |
| A4 | 1268.498 | E11 −0.066, E21 +0.007, **E131 −0.060** |
| B0 | 1371.739 | E11 −0.065, E21 −0.080, E131 −3.727 (not a burst start) |
| B1 | 1124.407 | E11 −0.042, E21 +0.013, **E131 −0.016** |
| B2 | 1209.862 | E11 −0.097, E21 −0.068, E131 −4.290 (not a burst start) |
| B3 | 1261.938 | E11 −0.058, E21 −0.036, E131 −3.838 (not a burst start) |
| B4 | 1244.992 | E11 −0.052, E21 −0.021, E131 −3.448 (not a burst start) |

**Uncertainty: ≤0.10 ms** on the two anchors available in all 10 traces
(E11, E21). **Four** runs also carry E131 within 0.10 ms (A2, A3, A4,
B1, bold above); in the other six the E131-side write merged with
neighbours or landed elsewhere, so that anchor is reported as
unavailable rather than as an alignment value — the printed magnitudes
are the *observed* residual there, not a sub-0.1 ms anchor.

*Discriminating evidence for `A` (why the first burst is W(E00) and not
something else):* the observed write bursts are at fixed offsets from
the marker chain only under this `A`. For A0 the bursts sit at
1753.516 / 1777.657 / 1848.863 ms = `A` + E00/E11/E21 (residuals above);
under the earlier ad-hoc timeline placement (`A0-timeline-1718.txt`,
E00 = 1718.670, from a preliminary offset superseded here) the bursts at
1777.657 and 1848.863 correspond to no marker write at all, and no
write-classified wait exists before 1753.516 to serve as an earlier
anchor. This is the mission's "per-trace, multi-anchor, sub-ms"
requirement satisfied from the data itself — not from a stage
assumption.

*Harness write cost (measured, and present in the baselines too):* each
marker line costs ≈6 ms in the runner's environment (baseline campaign:
6.3–6.9 ms per write-adjacent gap; reproduced here: `Start-Process
-RedirectStandardError` 6.3/6.4 ms vs Python file/pipe handles
0.03–0.3 ms for the same binary). Inside the window it shows up as the
main thread's `Executive`-reason waits: 5.0–6.1 ms/run across the five
arm A `E20→E21` intervals (per-run 5.5 / 5.0 / 5.1 / 5.0 / 6.1). It is a
property of the measurement plumbing, identical in the clean baselines —
the headline E-series numbers are untouched.

## CORRECTIONS TO THE NON-ELEVATED PASS

1. **The bridge claim "`DxgKrnl Process/Start` fires at E20 begin (arm A)
   / E30 begin (arm B)" is not supported.** In all 10 elevated traces the
   DxgKrnl process attach (id 471) and the first Win32k user-handle create
   (id 452) fire **≈3.3–4.5 ms / ≈3.1–4.2 ms before E00** (471: A0
   −3.63 … A3 −4.45 … A4 −3.26; first 452: −3.14 … −4.21) — they are
   pre-main loader/CRT-init events in both arms, not winit window
   creation. Measured: A0 471 at 1749.884, first 452 at 1750.006, E00 at
   1753.516; B0 471 at 1367.872 (user imports finish 1363.3), E00 at
   1371.782; the same relative position appears in every trace. The in-process caller of
   those pre-main events is **not identified** (no stack linkage exists in
   the capture; DLL-init routines are candidates only) and is stated as
   unresolved rather than guessed. Consequence: the non-elevated pass's
   per-trace offsets `o` were internally consistent but semantically
   mis-anchored; its ARM A/ARM B narrative lines that read "process attach
   at E20 begin" are corrected here. The exact-LUID intervention and its
   −152.0 ms statistic are marker-only and unaffected. This is also why
   the elevated closeout aligns on the harness's own write bursts
   (§CLOCK ALIGNMENT) instead of on that event.
2. **The probes' "predominantly off-CPU driver-side wait" reading is
   refuted in its off-CPU part** by the scheduler records (≈97–98 %
   RUNNING in 9 of 10 probe windows; §PROBE #0/#1). This does *not*
   refute a kernel-mode locus: RUNNING includes kernel-mode execution on
   the calling thread, user-vs-kernel mode is unmeasurable here, and an
   on-CPU spin/poll inside the driver would also read RUNNING — so **no
   locus claim (driver or app) is made**.
3. The `E20→E21` "≈52–57 ms today / 68–74 ms historically" statement
   stands; the elevated data adds that 5.0–6.1 ms of any such window
   (arm A) is the harness's own stderr write in the `Executive` wait
   bucket (a runner-plumbing constant present in the clean baselines
   too).
4. **The non-elevated placement "after `E21`, at the first-redraw
   region" for the CDD/redirection cluster is corrected to *inside*
   `E20→E21`.** With the write-burst alignment the elevated A0 trace
   places `CddStandardAllocation`/`DeviceAllocation`/`GpuVirtualAddress
   Range`/`PagingQueuePacket`/fence/`Profiler` events at +27.0…+59.7 ms
   and `Win32k OldToNewRendering` (`Rendering`) at +59.65 ms — 4.6 ms
   before `E21` — and records **zero** child events between `E21` and
   `E130`. The earlier "after E21" reading came from the retired bridge.

## WINDOW_CREATE THREAD-STATE BREAKDOWN (Q1)

`E20→E21` (arm A, **elevated** session, in-trace), per trace, **main
thread** (the interval's owner); all values ms. The `P50` row is the
per-column median (not one run), so its columns do not sum:

| run | wall | RUNNING | READY | WAITING | residual¹ | dominant waits |
|---|---|---|---|---|---|---|
| A0 | 64.2 | 41.1 | 1.9 | 21.2 | 0.00 | WrResource 13.5, Executive 5.5 (stderr write), WrLpcReply 1.2, UserRequest 0.8 |
| A1 | 59.1 | 40.3 | 2.5 | 16.3 | 0.00 | WrResource 9.0, Executive 5.0 |
| A2 | 49.4 | 36.0 | 1.6 | 11.9 | 0.00 | Executive 5.1, WrResource 4.6 |
| A3 | 96.8 | 56.3 | 7.3 | 33.2 | 0.00 | WrResource 25.2, Executive 5.0 |
| A4 | 53.8 | 39.4 | 1.6 | 12.7 | 0.00 | Executive 6.1, WrResource 4.5 |
| **P50** | **59.1** | **40.3** | **1.9** | **16.3** | 0.00 | |

¹ The residual is a **coverage** check only: the interval owner's CSwitch
history tiles the window, so `wall − RUN − READY − WAIT ≡ 0` by
construction and it cannot detect an alignment error. Verified by
perturbation: shifting A0's window +20 ms leaves the residual at 0.0000
while RUN drops 41.1→33.9 and WAIT rises 21.2→28.3; only a +50 ms shift
breaks coverage (residual 8.4 ms). Alignment uncertainty is the
independent ±0.10 ms anchor result (§CLOCK ALIGNMENT).

State-classification granularity: the reducer labels a switch-out as
WAITING unless the thread was switched out with `OldState =
Standby/DeferredReady` (preempted-but-runnable = READY). With that strict
split applied, A0 `E20→E21` moves ≤0.1 ms (READY 1.883→1.975, WAITING
21.176→21.084; probe windows ≤0.06 ms) — below the resolution of every
number quoted here; the strict variant is archived as
`elevated/_probe/recheck-preempt.json`.

- **The interval is not one big wait.** No single *main-thread* wait in
  the five windows exceeds 0.79 ms (max A1); the wall is ≈2/3 on-CPU
  execution plus a dense stream of sub-ms lock/message/I-O waits —
  1,991 win32k-lock waits totalling 57.7 ms across the five arm-A runs
  (2,978 / 85.9 ms if the five arm-B `E20→E21` windows are included).
  The process's other threads do carry longer waits (24.8–78.2 ms, e.g.
  A0's workers 47.1/47.2/47.5 ms) — they are not the interval owner and
  are not part of this split.
- **Dominant wait: the win32k user lock.** Stack signature:
  `KeWaitForSingleObject ← ExpWaitForFastResource ←
  ExAcquireFastResourceExclusive ← win32kbase!EnterCrit` (also the shared
  variant via `NtUserGetThreadState`). Wake-source analysis: the threads
  that end these waits are overwhelmingly in *other* desktop processes —
  across the five arm-A runs **msedge.exe 579, explorer.exe 486,
  dwm.exe 237, esrv 180, QQPCTray 103, Weixin 69, …**, with only **21**
  wakes from the process's own threads (2,176 ready events total; the
  10-trace aggregate is explorer 1056 / msedge 735 / dwm 276 / own 39 of
  3,404). This is consistent with cross-process win32k lock contention —
  the same property the load-sensitivity of this stage would predict —
  but note the histogram is not filtered by wait reason (it includes
  I/O, message and quantum-end readies; 122 of the arm-A wakes come from
  `Idle`), and the waker of a `WrResource` wait is the releasing thread
  only *in aggregate*, not per event.
- **Second wait class: the harness's own stderr write** — the
  `Executive`-reason bucket, 5.0–6.1 ms/run inside the window, whose
  deepest symbolized stacks are the non-cached write path
  (`NtfsWaitOnIo ← NtfsNonCachedIo ← NtfsNonCachedUsaWrite ←
  NtfsFsdWrite ← FLTMGR ← Ntfs ← storage stack`); see CLOCK ALIGNMENT.
  Plus a console/ALPC residual (`WrLpcReply`, conhost).
- Sequence in the window (A0, kernel axis): **11** Win32k user-handle
  creates (first at +7.09 ms), the GDI-handle churn (1,065 of the trace's
  1,815 `GdiHandleOperation` events fall inside the window), the DxgKrnl
  allocation/VAD/fence/`CddStandardAllocation` cluster (+27.0…+59.7 ms),
  and `Win32k OldToNewRendering` at +59.65 ms — the DWM
  redirection-surface establishment as the window is shown, all inside
  `E20→E21`; between `E21` and `E130` there are zero child events.
- State-split caveat: RUNNING cannot be split into kernel/user (no
  sampling). What is *known* about that on-CPU time is what the window's
  manifest events place inside it (handle creates, GDI operations,
  DxgKrnl allocation/fence/redirection work); per-function attribution
  would need sampling the machine does not provide, so no further
  decomposition of RUNNING is claimed. The label `MIXED` in the old
  (non-elevated) table is superseded by this measured shape (≈2/3
  RUNNING, ≈1/3 sub-ms waits).

## PROBE #0 / #1 THREAD-STATE BREAKDOWN (Q2)

Arm B, in-trace (**elevated** session), **main thread**, ms:

| run | probe #0 (LUID 0-e1e6) wall/RUN/WAIT | probe #1 (LUID 0-1a8f2) wall/RUN/WAIT |
|---|---|---|
| B0 | 233.4 / 223.2 / 9.6 | 149.7 / 147.3 / 2.3 |
| B1 | 177.1 / 173.0 / 3.7 | 148.6 / 146.5 / 2.0 |
| B2 | 170.4 / 166.2 / 3.8 | 146.6 / 144.7 / 1.8 |
| B3 | 166.4 / 161.6 / 4.3 | 143.5 / 141.2 / 2.2 |
| B4 | 172.2 / 168.0 / 3.9 | 157.1 / 154.6 / 2.3 |
| **P50** | **172.2 / 168.0 / 3.9** | **148.6 / 146.5 / 2.2** |

(P50 row = per-column medians, not one run. READY totals — omitted above
for width — are 0.62 / 0.30 / 0.40 / 0.41 / 0.39 ms for probe #0 and
0.17 / 0.15 / 0.13 / 0.10 / 0.17 ms for probe #1.)

READY is ≤0.63 ms in every probe. **RUNNING is 97–98 % of wall in 9 of
the 10 probe windows; B0 probe #0 is 95.6 % (223.2 of 233.4 ms), the
disclosed outlier** (B0 is also the run whose whole startup carried the
~860 ms tail in the baseline). The waits are individually ≤0.85 ms (max:
B0 probe #0 0.851, B3 probe #0 0.759) and their signatures are
(a) `WaitForSynchronizationObject ← DxgkWaitForSynchronization` (GPU/paging
sync), (b) the harness's stderr write (NTFS), (c) ALPC, (d) residual
`KeWait*` — total 3.7–9.6 ms (P50 3.9) for probe #0 and 1.8–2.3 ms
(P50 2.2) for probe #1.

Wake sources inside probe #0: `Idle` 141 and **the process's own threads
125**, then lsass/csrss/System — i.e. no desktop herd (contrast with Q1);
the probes are self-contained CPU work with occasional internal sync.

Classification (mission vocabulary): **`CPU_HEAVY` — mode unresolved**
(user-vs-kernel split not collectible here). Its off-CPU blocking is
ruled out: not `WAITING_ON_DRIVER_OR_KERNEL` (off-CPU 1.8–9.6 ms against
143–233 ms wall), not `READY_SCHEDULER_DELAY` (≤0.63 ms) and not one big
wait; a kernel-mode *locus* (an on-CPU spin/poll inside the driver)
would also read as RUNNING and is neither confirmed nor excluded. The
adapter span `E50→E51` (P50 376.7 wall / 350.6 RUN) and the device create
`E60→E61` (42.4–75.5 wall / 33–50 RUN) follow the same pattern;
`E50a→E50b` (DXGI enum) is the one sub-stage that is *wait*-dominated —
4.1–4.6 ms of its ~6 ms is `Executive`-reason waiting, i.e. the harness's
own marker writes (the sub-stage brackets two of them).

## WAIT STACKS (resolved)

Resolved from the kernel ETL stack walks (module-level resolution in all
runs; function-level where the boot-wide symbol dictionary resolves the
frame; unresolved frames are stated as such).

**Attribution rule and its limits (review-driven):** stack walks are
emitted next to switch-in events, not at switch-outs, so each wait is
given a *nearby* walk — the analyzer takes the nearest within ±300 µs of
the switch-out (37 % of arm-A Q1 waits thereby get the walk of the
preceding switch-in). The counts under that rule and under "the walk at
the closing switch-in" agree for the win32k signature (arm-A Q1: 1,908
waits/57.2 ms vs 1,903/55.8 ms, ≤2.4 %), and the two rules describe the
same write burst at the window start (the residual difference is
symbolization depth: the same I/O chain appears as
`NtfsNonCached…`/`NtfsWaitOnIo` in one walk and as unresolved
`Ntfs.sys!0x…`/storage-stack frames in the other). Per-wait attribution
is therefore **not event-exact**; the signature set below is what is
robust. Dominant signatures:

| window | signature (top→bottom, abbreviated) | role |
|---|---|---|
| Q1 | `KeWaitForSingleObject ← ExpWaitForFastResource ← ExAcquireFastResourceExclusive ← win32kbase!EnterCrit` | cross-process win32k user-lock contention |
| Q1 | `NtfsWaitOnIo ← NtfsNonCachedIo ← NtfsNonCachedUsaWrite ← NtfsCommonWrite ← NtfsFsdWrite ← IofCallDriver ← FLTMGR ← IoSynchronousPageWrite ← LfsSynchronousPageWrite` | harness stderr write (non-cached) + NTFS log flush |
| Q1 | `AlpcpSignalAndWait ← NtAlpcSendWaitReceivePort` | console/ConDrv (or COM activation) |
| Q2 | `WaitForSynchronizationObject ← DxgkWaitForSynchronization` | GPU/paging sync object (sub-ms) |
| pre-main | `FLTMGR ← QQSysMonX64_EV.sys` (the 58.3 ms wait) and `QMUdisk64_ev.sys` (1.8 ms) | third-party (QQ PC Manager) minifilters in the loader's I/O path |
| pre-main | waits with no captured stack, ended by `conhost` / `QQPCRTP` threads (the 73.7 ms and 2.6 ms waits) | console attach / AV real-time scanning — *presence-level attribution only* |

## READY/WAKING ANALYSIS

READY is small in every window: 1.6–7.3 ms (2.5–9 % of wall) for Q1;
≤0.63 ms for the probes. The main thread's wake sources are the
load-bearing observation: **Q1 is woken mostly by other processes'
desktop threads** (across the five arm-A runs: msedge 579, explorer 486,
dwm 237, esrv 180, QQPCTray 103, Weixin 69, `Idle` 122 — i.e. the win32k
lock holders in aggregate; only 21 wakes from the process's own threads
of 2,176; the 10-trace aggregate is 1,056 / 735 / 276 / … / 39 of 3,404;
the histogram is reason-unfiltered, so it mixes lock, I/O, message and
quantum readies), **the probes mostly by Idle (141) and the
process's own threads (125)** of 345. Pre-main, the main thread is readied by
`QQPCRTP.exe` (AV real-time protection) and `conhost.exe`; the two long
pre-main waits are 58.3 ms (stack inside the QQ minifilter, see above)
and 73.7 ms (no captured stack; console-related by its waker) —
attribution stated at the level the evidence supports.

## KERNEL/USER CPU SPLIT

**NOT COLLECTED — `SAMPLED_PROFILE_UNAVAILABLE`.** Evidence: zero
`SampledProfile` rows under the built-in WPR `CPU` profile canary and
under the custom explicit-keyword profile; `xperf -a profile` over the
canary: "There is no sampled profile data in the trace". Consequence:
this report does not claim any kernel-vs-user CPU split; RUNNING is a
single scheduler state (it *includes* kernel-mode time inside the
thread's own syscalls, e.g. win32k/DxgKrnl/AMD-KMD execution on the
calling thread). The mission's per-stage RUNNING_USER/RUNNING_KERNEL
rows are therefore unavailable by measurement here, not by omission.

*(Superseded: the non-elevated pass's classification table above — its
"predominantly off-CPU driver-side wait" reading of the probes came from
the uProf-derived "tens of ms on-CPU" arithmetic and is contradicted by
the scheduler's own records: the probes are 97–98 % RUNNING (9 of 10
windows; B0 probe #0 95.6 %). The two sources are not averaged; the
CSwitch/ReadyThread reduction is the authority for state, and no
production conclusion rests on the earlier uProf impression.)*

## PERFVIEW CALL PATHS

PerfView 3.2.6 is installed and recorded, but contributed nothing: CPU
sampling / Thread Time require sampled-profile data this machine does not
produce (§KERNEL/USER CPU SPLIT), and the GUI `/?` produces no stdout to
archive. No PerfView-derived number is quoted anywhere in this report.

**WPA / wpaexporter (Phase 11 of the closeout):** `wpaexporter` runs
against the kernel ETLs with a shipped Catalog profile
(`AppLaunch.wpaProfile`, whose presets include the context-switch-based
"CPU Usage (Precise)" table); exports were produced for A0 and B1 under
`elevated/_probe/wpaexp-applaunch/` and `elevated/_probe/wpaexp-b1/`
(plus a `FastStartup.wpaprofile` run that yields disk/image tables only).
The precise table is generated *from the same CSwitch events* this audit
reduces directly, so it is a consistency cross-check, not an independent
measurement; its per-process aggregate magnitudes are consistent with
the direct reduction (e.g. A0 norm-a.exe ≈95 ms total CPU vs the direct
RUNNING sum of the same order), and no numbers from the two are
averaged. The scheduler authority for every number in this report is the
direct CSwitch/ReadyThread/stack reduction in
`tooling/analyze_elevated.py`.

## GRAPHICS STACK EVIDENCE

- Probes: near-silent at the DxgKrnl manifest level (ARM B); no
  adapter-GPU-VM allocations attributed to probe windows; the one dense
  cluster near probe#1's end is context/queue/paging machinery.
  *(Elevated update: the child's user-session D3D12/DXGI/Direct3DShaderCache
  providers do fire inside the probe windows — B0 whole-trace totals
  554 / 158 / 49, of which 173 / 53 / 25 fall inside the adapter span
  `E50→E51`, 52 / 10 / 14 inside probe #0 and 54 / 10 / 7 inside probe #1
  — but the state decomposition shows the probes are on-CPU regardless;
  the manifest silence below it is at the DxgKrnl/kernel-DDI level.)*
- Real init (E60+, surface, present): allocations, VAD, MakeResident,
  fences, present-queue packets, MMIO flip machinery — all present and
  loud, proving capture fidelity.
- Window path: win32k user/GDI handle churn + post-E21 CDD/redirection-
  surface allocation + `Rendering` event (the DxgKrnl process attach
  itself is pre-main — §CORRECTIONS).
- Dwm-Core/DXGI providers captured desktop-wide events; child-scoped
  DXGI activity concentrates in surface/swapchain/present regions
  (Profile events; swapchain release at teardown).

## DUPLICATE-LUID FINDINGS

- **Proven: YES.** `AUDIT_DXGI_ADAPTER` across the prior audit (4 runs),
  today's 5 ETW captures, and 20 pristine intervention runs is identical:
  the single AMD iGPU is enumerated by DXGI under two LUIDs —
  `0-e1e6` and `0-1a8f2` (same vid 0x1002 / pid 0x1638 / name) — plus
  Microsoft Basic Render Driver (0-f7f1).
- **Selected adapter: LUID 0-e1e6** — newly PROVEN this audit (the
  vendored wgpu-hal carries `+audit_luid=` on the AdapterInfo driver
  string under NORMTRACE; surfaced in every BENCHMARK_CONFIG; 40/40 runs).
  wgpu therefore pays the expensive `D3D12CreateDevice` probe for LUID
  0-1a8f2 without ever selecting it.

## HYPER-V/VBS STATUS

- Hypervisor present (HypervisorPresent=True; VBS running, HVCI off;
  Hyper-V VMBus/VSP/PCI infrastructure devices present).
- No GPU partitioning / GPU-PV / indirect-display device was found in
  the PnP inventory, and no DxgKrnl manifest evidence of paravirtualized
  exposure was observed. Hyper-V presence + duplicate LUID remains
  **correlation only**.
- Verdicts (mission vocabulary):
  - duplicate LUID with Hyper-V present: **DUPLICATE_LUID_WITH_HYPERV_PRESENT**
  - association: **HYPERV_ASSOCIATION_NOT_SUPPORTED** (no positive
    mechanism evidence found; nothing supporting a GPU-PV alias was
    observed)
  - causality: **HYPERV_CAUSALITY_NOT_PROVEN** (no configuration change
    was made or authorized)

## OPTIONAL EXACT-LUID INTERVENTION (Phase 10 — PERFORMED)

Reversible, measurement-only, env-gated (`ETW_AUDIT_SKIP_LUID`) skip in
the vendored wgpu-hal `enumerate_adapters`: exactly one LUID-matching
adapter is not enumerated → not exposed → not probed. No generic
dedup by VID/PID/name. Committed as `be58f53c` on the audit branch only.

- known non-selected LUID: **0-1a8f2** (selected 0-e1e6 proven per run)
- design: pristine = env unset (identical binary, skip compiled in but
  inactive); patched = env set; interleaved randomized, n=20 each, no
  ETW capture (marker-based timing, instrumented build)
- invariants held in 40/40 runs: selected adapter LUID unchanged
  (0-e1e6), adapter "AMD Radeon(TM) Graphics", backend Dx12,
  device_type IntegratedGpu, surface format Bgra8Unorm, present Fifo,
  full E00→E190 marker set

| metric (P50, ms) | pristine | patched | Δ |
|---|---|---|---|
| E50→E51 (adapter) | 358.0 | 206.0 | **−152.0** |
| probe #0 (AMD e1e6) | 168.9 | 170.8 | +1.9 (unchanged) |
| probe #1 slot | 144.5 (AMD 1a8f2) | 6.3 (MBRD) | −138.2 |
| E00→E190 | 569.1 | 419.5 | −149.6 |

Predicted ≈ −140 ms; measured −152.0 ms (adapter) with the endpoint
moving by the same amount and the selected probe unchanged.
**SECOND_PROBE_CAUSAL_OVERHEAD_CONFIRMED.** This does NOT authorize any
production dedup fix.

## WINDOW_CREATE STATUS

| field | value |
|---|---|
| total wall (clean, **arm A**, n=10) | 46.2 ms P50 (44.3–94.4) — the arm the traced rows below belong to |
| total wall (clean, arm C, n=20) | 51.6 ms P50 (the full-host arm; 95 % CI band across recent audits 45–116; prior audit 73.8; load-sensitive) |
| total wall (traced, arm A, elevated, n=5) | 59.1 ms P50 (49.4–96.8) — same arm, ETW-observed |
| running / ready / waiting | **ANSWERED (elevated)**: RUN 40.3 P50 / READY 1.9 / WAIT 16.3 / residual 0.00 ms (coverage check only) — ≈2/3 on-CPU, ≈1/3 sub-ms waits |
| kernel vs user split | NOT COLLECTED (`SAMPLED_PROFILE_UNAVAILABLE` on this machine) |
| dominant wait | win32k user lock (`EnterCrit`); the threads ending those waits are overwhelmingly other desktop processes' — cross-process contention in aggregate |
| a specific 40–60 ms wait? | **ABSENT** — no single main-thread wait >0.79 ms; the interval is execution + dense sub-ms lock/I-O waits |
| confidence | state split: high (scheduler records); kernel/user mode: unavailable |

The historical "~70 ms" window_create is today 46.2 ms clean on this host
(arm A, n=10; arm C 51.6 ms, n=20); the delta remains consistent with the
documented background-load sensitivity of this machine — the measured
in-window lock wait (4.5–25.2 ms/run, n=5) and the desktop-process wakers
are *consistent with* that reading but do not by themselves prove it (no
quiet-desktop control was run) — not with a code change (same binaries as
the prior audit).

## LIMITATIONS

1. ~~Non-elevated shell: no CSwitch/ReadyThread…~~ **Resolved** by the
   elevated closeout (5+5 valid kernel traces; §ELEVATED KERNEL TRACE).
2. NT Kernel Logger occupied (0xb7) and named xperf kernel sessions
   rejected (0x3ec) on this build — the elevated capture therefore uses
   WPR system loggers (measured; strategy battery in the DONE marker).
3. **`SampledProfile` unavailable on this machine** (two independent
   profile definitions, zero rows; `xperf -a profile` confirms) → no
   kernel/user CPU split; RUNNING reported as one state.
4. In-trace numbers carry ETW observer overhead; the *shape* (stage
   ordering, state mix) is stable but absolute walls inflate
   run-to-run (arm A `E20→E21` 49.4–96.8 ms traced vs 46.2 clean P50 for
   the same arm; arm B probe #0 up to 233 ms in the first traced run vs
   166–177 in the rest). Headline numbers remain the untraced E-series.
   The per-run lists in the ARM A / ARM B sections are the **non-elevated**
   session; the Q1/Q2 tables and all `elevated-analysis.json` values are
   the elevated one.
5. Alignment is per-trace and derived from the harness's own write
   bursts (≤0.10 ms anchor agreement); it inherits one systemic term —
   the approximately 6 ms per marker line the runner's redirect adds
   inside every window that contains a marker write.
6. tracerpt CSV gives provider/task/opcode/PID/timing but no payloads —
   no per-event field analysis (e.g., present LUIDs); only presence,
   sequence, and density are used.
7. D3D12/DXGI/ShaderCache user-session providers were captured for arm B
   (whole-trace child events in B0: 554 / 158 / 49) but used only as
   presence/density context.
8. Stack walks resolve to module level everywhere; function names come
   from a boot-wide address dictionary built from partial symbol dumps
   (789 entries) — unresolved frames are reported as module+offset, and
   the pre-main DxgKrnl-attach caller could not be identified. Wait-stack
   attribution is nearest-walk, not event-exact, and symbolization depth
   varies between walks of the same chain (§WAIT STACKS).
9. Single machine; driver/hypervisor states as recorded in MACHINE
   STATE; the desktop was busy (explorer/Edge/WeChat/ctfmon active) and
   that activity is *inside* the Q1 measurement (see §WAKE SOURCES).
10. The Q1 window aggregate numbers are quoted per run-set: **arm A only**
    where the five arm-A traces are meant (wait count/ms, wakes); the
    10-trace aggregate is given separately when used, and the two are not
    mixed. The Q1 aggregate surface is the *arm-A main thread* unless
    stated otherwise.

## CAUSALITY STATUS

- Second-probe overhead (adapter span): **CONFIRMED CAUSALLY**
  (reversible exact-LUID skip, interleaved n=20+20, invariants held,
  −152.0 ms on E50→E51 with selected adapter unchanged). Unchanged.
- Duplicate-LUID origin (why DXGI enumerates two LUIDs): **NOT PROVEN**;
  Hyper-V/VBS association not supported by any mechanism evidence found;
  causality explicitly not tested (no configuration change authorized).
  The elevated traces add no new virtualization evidence: the child's
  GPU stack shows one AMD device (DXGI/D3D12 events on both LUID probes
  only as adapter enumeration results), no GPU-PV/indirect-display
  events.
- Probe-internal mechanism (what the ≈168/≈146 ms is doing):
  **PARTIALLY EXPLAINED** — the state is now measured: 97–98 % on-CPU
  execution (RUNNING) in 9 of 10 probe windows, 1.8–9.6 ms of sub-ms
  waits in the `DxgkWaitForSynchronization` path, wakes dominated by Idle
  and the process's own threads. What the CPU time is *spent on* inside
  the D3D12/AMD user-mode + kernel driver path is **not** further resolved
  (no sampling; no per-function CPU attribution). The earlier
  "blocked in the driver" hypothesis is refuted **only in its off-CPU
  form**: user-vs-kernel mode is unmeasurable here and an on-CPU
  spin/poll inside a driver would also read RUNNING, so no locus claim is
  made; "CPU_HEAVY (mode unresolved)" is the evidence-earned label.
- window_create ~49–97 ms (traced) / 46.2 clean (arm A): **EXPLAINED at
  the state level** — ≈2/3 RUNNING, ≈1/3 sub-ms waits whose dominant
  signature is the cross-process win32k user-lock and whose second
  class is the harness's own stderr write; no single blocking wait
  exists. The *content* of RUNNING is **not** attributed: the window's
  manifest events (handle churn, redirection setup) place what is inside
  it, but per-function CPU attribution would need the sampling this
  machine does not produce.

## DISPOSITION

**`PASS_WITH_OPEN_CAUSE`** (review-driven corrections applied; see
§REVIEWS). The elevated kernel capture ran (one UAC; unattended; cleanup
verified) and answered Q1 and Q2 with valid scheduler-level evidence and
a per-trace sub-0.1 ms alignment. The open cause is observational, not
architectural: `SampledProfile` is unavailable on this machine, so the
mission's kernel-vs-user CPU split is not obtainable here (RUNNING is
reported unsplit); one residual attribution (pre-main DxgKrnl attach
caller) is likewise unresolved. The corrected non-elevated claims are
listed in §CORRECTIONS TO THE NON-ELEVATED PASS. No production fix is
authorized by this audit. #42/#43 untouched. Not merged.

## REVIEWS

The non-elevated pass closed with the review step waived by the owner
(2026-09-14) after two cancelled reviewer dispatches — that history
stands for that pass. **This elevated closeout did NOT waive review.**
Two fresh-context adversarial reviewers were dispatched against the
report revision as it stood at 13:40 on 2026-09-14 (uncommitted working
tree; the reviewers flagged that the file changed under them, so the
reviewed revision is pinned by the commit that records these
corrections) plus the raw evidence. **Both returned, both verdict
`REVISE`; every BLOCKER/MAJOR and every MINOR below is fixed in this
revision** unless the row says otherwise. Reviewer A independently
rebuilt the A0/B1 thread-state tables, the CSwitch polarity and
RUNNING/READY/WAITING episode rules, the write-burst alignment, the
"first burst = W(E00)" assumption and the PID/TID filtering — all
reproduced 1:1 (no finding on those axes) — and Reviewer B reproduced
the intervention table, the pre-main placement, the probe on/off-CPU
split and the no-production-fix language.

- **REVIEWER A (scheduler / ETW): REVISE.** Findings, all fixed:
  [MAJOR→fixed] Q1 headline aggregates (win32k-lock wait count, wake
  sources) were the **10-trace** sums labelled "across the 5 runs" — now
  split per run-set (arm A: 1,991 waits/57.7 ms; msedge 579 / explorer
  486 / dwm 237 / own 21 of 2,176; the 10-trace totals are stated
  separately where used). [MAJOR→fixed] "residual ≈ 0.00" is a
  coverage artifact, not an alignment check — re-worded with the ±20 ms
  perturbation demonstration. [MAJOR→fixed] wait-stack attribution is
  nearest-walk (±300 µs, only at switch-ins), not event-exact — the rule,
  its 37 % preceding-walk share and the ≤2.4 % rule sensitivity are now
  stated in §WAIT STACKS. [MINOR→fixed] probe bounds exceeded by B0
  probe #0 (95.6 % RUN, READY 0.62 ms, max wait 0.851 ms) — disclosed as
  the outlier; [MINOR→fixed] "5 runs carry E131 within 0.10 ms" → 4
  (A2/A3/A4/B1) with the non-anchor residuals labelled; [MINOR→fixed]
  child CSwitch range 1,401–4,172; [MINOR→fixed] 11 (not 10) Win32k
  user-handle creates in A0's window, first at +7.09 ms; [MINOR→fixed]
  the two campaigns' per-run lists are now labelled non-elevated vs
  elevated; [MINOR→fixed] the harness-write cost is quoted as the
  `Executive` bucket (5.0–6.1 ms/run arm A); [MINOR→fixed] P50 rows are
  labelled per-column medians; [MINOR→fixed] strict-preempt probe
  movement ≤0.06 ms. Could-not-verify items (the retired bridge's `o`
  offsets; the non-elevated GdiHandleOperation density) are now stated as
  such in the report.
- **REVIEWER B (causality / attribution): REVISE.** Findings, all fixed:
  [MAJOR→fixed] "post-E21 CDD/redirection" corrected to *inside*
  `E20→E21` (+27.0…+59.7 ms; zero child events between `E21` and
  `E130`), matching the report's own elevated sequence; [MAJOR→fixed]
  "mechanistically explained by the win32k-lock contention" softened to
  *consistent with* the documented load-sensitivity (4.5–25.2 ms/run of
  lock wait, n=5, no quiet-desktop control); [MAJOR→fixed] the RUNNING
  content attribution in CAUSALITY STATUS now matches the Q1 caveat
  (RUNNING content unresolved); [MAJOR→fixed] "the blocked-in-the-driver
  hypothesis is refuted" → *off-CPU* blocking refuted, mode/locus
  unresolved; [MINOR→fixed] probe quantifiers corrected for the B0
  outlier; [MINOR→fixed] pre-main 471/452 range ≈3.3–4.5 ms; [MINOR→fixed]
  E131 anchor count; [MINOR→fixed] B0 provider counts scoped
  (whole-trace 554/158/49 vs in-window 173/53/25, 52/10/14, 54/10/7);
  [MINOR→fixed] WINDOW_CREATE STATUS no longer mixes arm A's traced rows
  with arm C's clean row (arm A clean 46.2 ms, n=10); [MINOR→fixed]
  wake-source histogram qualified (reason-unfiltered; waker-of-lock
  claim is aggregate-only); [MINOR→fixed] machine-state/PnP claims now
  cite the archived read-only readback; resident sessions 56 (not "27+");
  both campaigns' labels distinguished. Reviewer B's own checks
  (intervention table, no-production-fix grep, QQ minifilter stack rows,
  harness write-cost A/B, session-dump byte-identity) reproduced clean.

Neither reviewer found a BLOCKER. If a future re-audit cannot run these
checks, that must be stated explicitly rather than replaced by an
invented PASS.

## NEXT ACTION (exactly one bounded experiment)

Obtain the **kernel-vs-user CPU split** for the two `D3D12CreateDevice`
probe windows — the only mandated item this machine cannot produce — by
re-running the same already-validated capture
(`tooling/win-etw-elevated-rerun.ps1`, unchanged) on a host where
`SampledProfile` is available, or on this host once the resident
kernel-logger conflict (0xb7/0x3ec) is cleared so a `Profile` group can
be enabled. Everything else the mission asked for is measured; no other
experiment is queued by this closeout.

STOP. No merge. No production optimization. #42/#43 untouched.
