# SELECTED EVIDENCE — DESKTOP-STARTUP-PERFORMANCE-EXPERIMENTAL-RECORD-1

This archive is a curated subset of the retained evidence behind
`docs/DESKTOP-STARTUP-PERFORMANCE-EXPERIMENTAL-RECORD-1.md`. It is NOT the
complete raw evidence set: several campaigns retain their full per-run
artifacts on dedicated archive branches (see
`docs/desktop-startup-performance-experimental-record-1/evidence-index.md`
for every path and hash). The selection contains what is needed to
recompute and audit the published headline numbers, including the PocketJS
measurement-only patch series behind the instrumentation and the causal
intervention.

Packaging properties: deterministic (sorted paths, uid/gid 0, empty
uname/gname, mtime 0, gzip mtime 0), members carry byte-exact copies of
the canonical git blobs (extracted via `git cat-file blob`, so no
working-tree CRLF/EOL conversion) or of the retained worktree evidence
files. Archive SHA256 is recorded in the companion index.

## Contents

### cross-os-normalized/ — CROSS-OS-NORMALIZED-DESKTOP-STARTUP-1 (#43)

- `raw-evidence.tar.gz` — the campaign's complete 230-file raw evidence
  subtree (per-run NORMTRACE logs, frozen summaries, machine states, DAG
  dump, runner/parser/audit scripts, windows-target guest bundle,
  Windows wedge evidence, RUNLOG.md). Already published on `main` under
  `docs/cross-os-normalized-desktop-startup-1/`; included here so the
  consolidated record is self-contained.
- `raw-evidence.sha256` — published hash of that archive
  (`9d55742d1f6350226726dfa5f2347eebd03c4b3d7100395127df0ced3e540219`).
- `raw-evidence-contents.txt` — sorted 230-entry member list.
- `stages-summary.csv` — Linux normalized per-stage P50/P95 (own +
  completion), n=50.
- `source-identity.md` — source/toolchain/guest identity for both hosts.

### linux-control/ — LINUX-DESKTOP-STARTUP-CONTROL-1 (closeout branch)

- `stats-all-batches.csv` — every retained batch's n/P50/P95/min/max/IQR
  with its validity label (gate vs exploratory).
- `source-identity-manifest.md` — source identity manifest as merged to
  the closeout branch.
- `pv-run-samples.sh`, `pv-stats.py` — the runner and statistics scripts
  needed to recompute the batch summaries from per-sample CSVs (which are
  retained on `archive/linux-desktop-startup-control-1-full`).
- Full raw evidence: `archive/linux-desktop-startup-control-1-full`
  @ `982914b598171045ffa38eefa3ebbc6df6e981e2`, paths
  `docs/linux-startup-control-1-raw/` (see evidence index).

### windows-t1-anchor/ — WINDOW-STARTUP-CRITICAL-PATH-REALITY-AUDIT-1 (#40)

- `bench-startup.ps1` — the existing external probe (QPC stopwatch,
  minimized spawn, stdout poll, nearest-rank percentiles).
- `audit2-join3.ps1` — the persisted wall-clock join family (kernel
  `Process.StartTime` ↔ process `READY <unix_ms>` epoch ↔ present_done),
  i.e. the T1-anchor/pre-main measurement.
- `audit2-exp.ps1` — the ABBA interleaving experiment runner (E2/E3a/
  E3b/E4/E5).
- `audit2-machine-state.ps1` — machine-state recorder.
- `audit1-load.ps1` — the background-load intervention runner
  (STARTUP-LAST-MILE-REALITY-AUDIT-1's mechanism proof).
- `audit2-markers-applied.diff` — the full measurement-only
  instrumentation patch (fine-grained A7EVENT markers, experiment env
  hooks, warm-window probe) applied to the throwaway PocketJS worktree.
- `warm-window-second-create.txt` — the six raw
  `A7EVENT,dur,warm_window_create` values behind the ≈13 ms intrinsic
  winit/`CreateWindowExW` cost (median 13.17 ms linear).
- `join3-hello.csv` — the persisted join3 hello-world control family
  (`printToCreate` = kernel create → first print; median 122.5 ms).
- `README.md` — what each of the above contains and reproduces.

### windows-callpath/ — WINDOWS-STARTUP-CALLPATH-REALITY-AUDIT-1

- `WINDOWS-STARTUP-CALLPATH-REALITY-AUDIT-1.md` — the report as committed
  on `audit/windows-startup-callpath-1`.
- `stages-summary.csv` — per-stage P50/P95/min/max/IQR for arms A/B/C and
  the instrumented nested-marker batches (pooled n=12).
- `source-identity.md` — PocketJS patch-series identity and tool identity.
- `reviews/reviewer1-measurement.txt`,
  `reviews/reviewer2-causality.txt` — both adversarial review verdicts
  (both PASS, MINOR cleanups only).
- `logs/machine-state-batch.txt`,
  `logs/machine-state-batch-attempt1.txt` — ambient-gate records for the
  published batches and for the discarded first attempt.

### windows-etw/ — WINDOWS-STARTUP-ETW-REALITY-AUDIT-1 (elevated closeout)

- `WINDOWS-STARTUP-ETW-REALITY-AUDIT-1.md` — the report as of the
  elevated closeout commit (`audit/windows-startup-etw-1` @ `f75c283`).
- `summary.csv` — headline, ETW-captured, and intervention numbers with
  their variants (n/P50/P95/min/max/IQR + notes).
- `source-tool-identity.md` — source identity + tool identity + non-admin
  capability matrix.
- `elevated-analysis.json` — the final elevated scheduler analysis for all
  10 traces (alignment, RUNNING/READY/WAITING per window, wait stacks,
  wake sources). Produced by `tooling/analyze_elevated.py`.
- `elevated-analysis.log` — the analyzer's full stdout for the same run.
- `recheck-preempt.json` — the strict preempted=READY variant of the
  A0/B1 states (archived variant; differences ≤0.1 ms).
- `ELEVATED-RUN-DONE.json` — capture completeness/cleanup marker
  (status PASS; one UAC approval; cleanup verified).
- `machine-state-readback-20260914.txt` — read-only readback behind the
  VBS/HVCI/PnP sentences (VBS running, HVCI off, one Display-class
  device, no GPU-PV/IDD device; resident-session before/after identity).
- `tooling/analyze_elevated.py`,
  `tooling/compare_intervene.py`,
  `tooling/win-etw-elevated-rerun.ps1`,
  `tooling/win-etw-intervene.ps1`,
  `tooling/pv-etw-audit.wprp` — analyzer, intervention comparator,
  capture runner, intervention runner, WPR profile
  (`pv-etw-audit.wprp` sha256 `3341a9593d416617852b7594dfb91cbe049bacf438245a5756e1e6af48727adc`,
  the hash quoted in the report).
- `intervene/pristine/run-000..019.log` +
  `intervene/patched/run-000..019.log` — the exact-LUID causal
  experiment's raw NORMTRACE stderr for all 40 runs (pristine =
  env unset; patched = exact-LUID skip of `0-1a8f2`). Reproduce with:
  `python compare_intervene.py <this dir>` after placing the two arms in
  `pristine/` and `patched/`.

### pocketjs-audit-patch/ — measurement-only PocketJS provenance

- `wgpu-hal-marker-instrumentation.patch` — the full audit series
  `e15674db..be58f53c` over the files the audits modified: nested E50a–h
  markers, the env-gated exact-LUID skip, adapter name/LUID emission, the
  hook, and the host-side plumbing.
- `wgpu-hal-exact-luid-skip.patch` — the intervention commit alone
  (`9a1b8d69..be58f53c`).
- `README.md` — base/commit table and the unset-path no-op guarantee.

The PocketJS audit branches are **local-only** (not pushed to the PocketJS
remote); these patches, plus the commit list in the README, are the
portable provenance for the instrumentation and the intervention.

## Explicitly NOT included (retained elsewhere; paths in evidence-index)

- per-run ETL traces (12–23 MiB each, 10 elevated + 10 non-elevated);
- AMD uProf session databases and report CSVs of the callpath audit;
- the per-run instrumented n=8 logs behind §10.3 of the record (their
  pooled aggregate is in `windows-callpath/stages-summary.csv`; the
  per-run share 88.5–89.0 % is recorded in the report and reproducible
  only from the host worktree);
- headline/profiled binary target directories and PDBs;
- the 230-file cross-OS raw subtree as loose files (present inside
  `cross-os-normalized/raw-evidence.tar.gz`).
