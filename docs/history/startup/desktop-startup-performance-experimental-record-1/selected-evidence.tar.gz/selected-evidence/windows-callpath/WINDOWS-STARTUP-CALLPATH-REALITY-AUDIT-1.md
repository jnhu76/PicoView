# WINDOWS-STARTUP-CALLPATH-REALITY-AUDIT-1

Windows-only startup call-path decomposition for the PicoView / PocketJS
desktop host: process main entry (E00) → first usable present (E190,
present-submitted proxy — not display photon latency). Independent of the
#43 cross-OS closeout; no Linux data, no Vulkan dependency, no production
optimization.

## SOURCE

| item | identity |
|---|---|
| PicoView branch | `audit/windows-startup-callpath-1` |
| PicoView SHA | `491d0a5` (= origin/main at freeze) |
| PicoView worktree | `C:\Users\fred1\source\PicoView-win-startup` (isolated; the session worktree on `exp/cross-os-normalized-desktop-startup-1-slim` was never touched) |
| PocketJS branch | `audit/windows-startup-callpath-1` (in `C:\Users\fred1\source\pocketjs-win-startup`) |
| PocketJS SHA | effective `4b2de0a4` = base `e15674db` (tree f09cf9fa, E00–E190 instrumentation series) + 3 audit-local measurement-only commits: `2ca5dc4c` (arm-B backend selector), `66df576f` (vendored wgpu-hal 25.0.2 + E50a–h nested markers under `vendor/wgpu-hal`, `[patch.crates-io]`, never upstreamed), `4b2de0a4` (DXGI adapter name/LUID emission) |
| Guest | frozen cross-OS windows-app bundle `picoview-a6-main` (js 357,862 B / pak 304,944 B, referenced read-only from the prior campaign's `dist-winref`; identical bytes per `docs/cross-os-normalized-desktop-startup-1/source-identity.md`) |

## TOOLS

| tool | identity |
|---|---|
| AMD uProf | version 5.3.521.0, CLI `C:\Program Files\AMD\AMDuProf\bin\AMDuProfCLI.exe` |
| rustc | 1.98.1 (48a229cea 2026-09-01), host x86_64-pc-windows-msvc |
| cargo | 1.98.1 (797e8a9bc 2026-08-05) |
| symbols | PASS — PDB (`CARGO_PROFILE_RELEASE_DEBUG=2`) resolves full demangled Rust frames incl. source lines (winit 0.30.13, wgpu 25.0.2, wgpu-core, naga); system DLLs have no function symbols but module attribution (amdxc64.dll, d3dcompiler_47.dll, ntdll, user32, win32u, d3dscache, d3d12core) is exact |
| backend | **Dx12** — runtime verified on every headline run via `BENCHMARK_CONFIG.gpu.adapter_backend = "Dx12"` (adapter "AMD Radeon(TM) Graphics", IntegratedGpu, Bgra8Unorm, Fifo); selected with the host's existing `POCKET_GPU_BACKEND=DX12` measurement selector; product unset default (Vulkan) unchanged |

Two build types: HEADLINE (release, `debug=false`, isolated
`target-win-startup-audit`) is the timing authority; PROFILE
(`CARGO_PROFILE_RELEASE_DEBUG=2`, `target-win-startup-audit-prof`) and the
wgpu-hal-instrumented build (`target-win-startup-audit-wgpu`) are analysis
aids whose absolute numbers are never quoted as headline results.

## BASELINE (visible windows, ambient gate P95<20% passed per batch, n valid/invalid)

| arm | endpoint | P50 | P95 | min | max | IQR | n |
|---|---|---|---|---|---|---|---|
| A winit only | E00→E199 (first redraw) | **132.1 ms** | 144.7 | 121.6 | 270.8 | 3.78 | 20/0 |
| B winit + wgpu DX12 | E00→E190 | **560.9 ms** | 598.3 | 545.9 | 615.4 | 12.24 | 20/0 |
| C full PocketJS | E00→E190 | **585.8 ms** | 600.6 | 573.7 | 604.3 | 9.55 | 50/0 |

`config_uniform` PASS on all three batches (no per-run drift; one GPU
policy variant). Arms are structural ablation evidence only — B−A and C−B
are NOT additive (the C DAG overlaps guest boot with GPU init).

Machine: Windows 11 Pro 26200, Ryzen 7 5800H (8C/16T), 28.9 GiB RAM, AMD
Radeon iGPU driver 31.0.21923.11000 (Adrenalin 25.8.1), 2560x1440@60,
scale 1.0 (`POCKET_FORCE_SCALE=1.0`, density 1). Hyper-V/VBS active (uProf
session metadata: Virtual Machine=Yes, hypervisor Microsoft Hyper-V).
QQPCRTP resident, WinDefend service stopped (pre-existing). Ambient gates
for the published batches all passed on attempt 1 (VERIFY P95 11.0,
BATCH-A 9.55, BATCH-B 8.0, BATCH-C 14.65 — `logs/machine-state-batch.txt`).
A first collection attempt was DISCARDED whole: its verify gate failed
(P95 72.05) and, after two batches' gates passed, its BATCH-C gate failed
(P95 57.55) before any C sample ran; it is archived as
`logs/machine-state-batch-attempt1.txt` and contributes nothing published.

## TOP WINDOWS STAGES (arm C, own duration = BEGIN→END on one clock)

| # | stage | P50 | P95 | lane | critical path | overlapped? |
|---|---|---|---|---|---|---|
| 1 | `adapter` E50→E51 (wgpu request_adapter) | **338.0 ms** | 351.5 | main | yes (completion 481 ms) | no — strictly serial after window+surface |
| 2 | `window_create` E20→E21 (winit create_window) | 73.8 ms | 78.8 | main | yes (completion 118 ms) | partially (instance thread runs beside it) |
| 3 | `device` E60→E61 (wgpu request_device) | 40.2 ms | 41.6 | main | yes (completion 523 ms) | no |

Secondary: `runtime_boot` 52.5 ms P50 (worker thread, fully overlapped —
completes 176 ms, then waits ≈364 ms for the GPU lane); `gpu_instance`
42.7 ms (side thread, fully overlapped — done at 80 ms, needed at 143 ms);
`present_call` (first `Present`) 13.3 ms; `surface_config` 7.0 ms;
`blit_ensure` 6.6 ms (first blit pipeline); `render` 4.1 ms. (`guest_eval`
P50 24.3 ms is over n=48 — the once-per-process E87/E88 pair was consumed
by a frameless early redraw in 2 of 50 runs.)

The historical "unexplained ~50–70 ms Windows-side cost" corresponds to
arm A `window_create` (P50 68.6 ms there): it is on-CPU-light (arm A whole
process ≈ tens of ms CPU; samples land in user32/ntdll) and is NOT the
dominant term under the production DX12 backend.

## UPROF CALL-PATH FINDINGS

Whole-process on-CPU (arm B/C sessions, hotspots + callstack sampling):
≈50–90 ms CPU vs 561–586 ms E00→E190 wall → **the startup path is
predominantly off-CPU**. Hottest modules: `amdxc64.dll` (AMD D3D12
user-mode driver) ≈28–30 ms, `d3dcompiler_47.dll` ≈13–30 ms, `ntdll.dll`
≈20–30 ms (syscall/wait paths), `d3dscache.dll`, `d3d12core.dll`, host exe
(wgpu-core/naga) ≈10 ms. uProf callgraphs resolve the user-mode Rust chain
`norm_b::resumed → wgpu::api::instance::Instance::request_adapter /
wgpu::api::adapter::Adapter::request_device` (with source files/lines);
the hop from the wgpu API into wgpu-hal dx12 is proven by the nested
markers plus source inspection below, not by callgraph frames (the hal
frames are inlined/dropped from the committed extracts). uProf
`--thread` (thread-state timeline) requires administrator and was not
available; wait-state evidence below is the honest wall-vs-on-CPU
arithmetic, not a scheduler trace.

Material-stage mapping (wall span → thread → on-CPU path → modules):

| stage | wall | thread | on-CPU | wait/off-CPU | modules | confidence |
|---|---|---|---|---|---|---|
| event-loop build E10→E11 | ~32 ms | main | light | win32k/msg-thread setup | winit, user32, ntdll | medium (A-arm samples sparse) |
| window create E20→E21 | 69–74 ms | main | light (user32/ntdll frames) | majority — kernel/DWM side | winit → CreateWindowExW → user32/win32u | high (consistent A/B/C) |
| gpu instance E30→E31 | 27–43 ms | side thread | d3d12/dxgi DLL load + factory | partially | wgpu-hal, d3d12core, dxgi | high |
| **adapter E50→E51** | 313–338 ms | main | ~20–40 ms (callgraph deep samples; amdxc64 + ntdll) | **~270–300 ms blocked in driver** | wgpu-hal dx12 → D3D12CreateDevice → amdxc64 (kernel side unobserved: user-mode sampling cannot see dxgkrnl) | high (nested-marker proof below) |
| device E60→E61 | 40 ms | main | naga validation + d3dcompiler frames present | part | wgpu-core, naga, d3dcompiler_47 | medium-high |
| runtime boot E80→E89 | 52.5 ms | worker | asset 7.2 + QuickJS 1.4 + guest eval 24.3 + glue | none material | pocketjs-core, QuickJS | high |
| first frame E100→E190 | ~43 ms | worker+main | render 4.1, blit 6.6, present 13.3 | present Call blocks ~13 ms | wgpu, dcomp/dxgi swapchain | high |

### Nested-marker proof (Phase 11, instrumented build, B arm)

P50s below are from the n=8 `wgpu-decomp` batch (the n=4
`wgpu-decomp-named` batch adds adapter identity only;
`docs/windows-startup-callpath-1/stages-summary.csv` pools n=12 for
reference — pooled P50s differ only ~1–9 ms: span 352.1, probes
164.9/141.6, same 87–88% share). `request_adapter` (wgpu-hal dx12
`enumerate_adapters` → per-adapter `Adapter::expose` →
`D3D12Lib::create_device` capability probe) decomposes as (P50, ms):

| segment | P50 | evidence |
|---|---|---|
| DXGI `EnumAdapters1` enumeration | 6.0 | E50a→E50b |
| probe #0 D3D12CreateDevice — "AMD Radeon(TM) Graphics", vid 0x1002 pid 0x1638, **LUID 0-e1e6** | **162.9** | E50e0→E50f0 |
| probe #0 feature/desc queries | 1.7 | E50g0→E50h0 |
| probe #1 D3D12CreateDevice — "AMD Radeon(TM) Graphics", vid 0x1002 pid 0x1638, **LUID 0-1a8f2** | **140.2** | E50e1→E50f1 |
| probe #1 feature/desc queries | 1.7 | E50g1→E50h1 |
| probe #2 D3D12CreateDevice — "Microsoft Basic Render Driver" (0x1414:0x8c) | 6.0 | E50e2→E50f2 |
| probe #2 queries | 1.2 | E50g2→E50h2 |

The two AMD probes alone are **~303 ms of the ~344 ms instrumented-build
span (88%)** (headline-build span, uninstrumented: 313 ms in arm B / 338 ms
in arm C — the instrumented build carries the vendored-patch overhead).
Adapter identity lines (`AUDIT_DXGI_ADAPTER`) are identical in 4/4 named
runs: **DXGI exposes the single AMD iGPU as two distinct-LUID adapters**;
`wgpu-hal` probes every enumerated adapter with a real `D3D12CreateDevice`
(expose must fetch capabilities before selection; `should_keep_adapter`
filters only Intel Haswell), so the AMD user-mode driver init cost is paid
twice, serially, on the main thread. The chosen adapter for rendering is
one of the two AMD entries; MBRD is probed but never selected.

## STARTUP TREE (measured; arm C P50 completion times, one Instant origin)

```
E00 main entry                                            0.0 ms
├─ args/logger → E10 event-loop begin                     6.0 ms
├─ E10→E11 event-loop build                             ~32 ms   [main, light CPU, win32k setup]
├─ E20→E21 create_window (winit→CreateWindowExW)          74 ms   [main; mostly kernel/DWM wait]
│  ║ (side thread) E30→E31 wgpu Instance (dxgi/d3d12 load) 43 ms — done at 80 ms, NOT critical
├─ E40→E41 surface create                              5.6 ms   [main]
├─ E50→E51 request_adapter                             338 ms   [main, CRITICAL]
│  ├─ EnumAdapters1                                       6 ms
│  ├─ expose AMD LUID e1e6: D3D12CreateDevice          ~163 ms   [blocked in amdxc64/driver]
│  ├─ expose AMD LUID 1a8f2: D3D12CreateDevice         ~140 ms   [blocked in amdxc64/driver]
│  └─ expose MBRD: D3D12CreateDevice + queries           ~8 ms
│  ║ (worker thread) E80→E89 runtime boot 52.5 ms (assets 7.2 / QuickJS 1.4 /
│  ║  guest eval 24.3 [n=48: E87/E88 once-consumed early in 2/50 runs] / glue)
│  ║  — done at 176 ms, then blocked on GPU (E90→E91 wait ≈364 ms)
├─ E60→E61 request_device (chosen AMD adapter)           40 ms   [main; naga+d3dcompiler present]
├─ E70→E73 caps + surface config                       9.1 ms   [main]
├─ E91 renderer ready (worker wakes; UiRenderer init)  542.5 ms
├─ E100 first tick begins 543.9; E110→E113 render      547→551 ms [worker; 4.1 ms]
├─ E122/E130 wake → redraw request                    553→555 ms
├─ E140→E162 acquire 1.0 / blit 6.6 / encode 1.3 / submit 569 ms
├─ E180→E181 Present()                                 13.3 ms   [main]
└─ E190 FIRST USABLE PRESENT SUBMITTED                 585.8 ms
```

## PRIMARY SUSPECT

- stage: `adapter` E50→E51 (wgpu `request_adapter`, dx12 backend)
- function/system boundary: `wgpu-hal dx12 enumerate_adapters →
  Adapter::expose → D3D12Lib::create_device` → `D3D12CreateDevice` in
  AMD user-mode driver (amdxc64.dll), executed twice because DXGI
  enumerates the single AMD iGPU under two LUIDs on this host
- observed cost: 338 ms P50 of a 585.8 ms E00→E190 (58%), headline build;
  in the instrumented build the two AMD probes alone sum to ~303 ms
  (88% of its ~344 ms adapter span)
- proven: the full call path (Rust frames + markers + module
  attribution); that both expensive probes hit distinct-LUID AMD
  adapters; that the span is overwhelmingly off-CPU (on-CPU deep samples
  ~20–40 ms); that all queries/enum glue are single-digit ms
- NOT proven: WHY DXGI/VBS exposes the duplicate AMD LUID (Hyper-V GPU-PV
  aliasing is the hypothesis, untested); whether skipping the duplicate
  probe would actually remove ~140 ms (predictable, but never
  intervention-tested); any behavior on hosts without the duplicate

## VERDICT

**GPU_INIT_STAGE_DOMINANT** (adapter sub-stage: serial double
D3D12CreateDevice driver initialization inside wgpu's probe-everything
adapter enumeration).

## ROOT CAUSE

**NOT YET PROVEN** at the "why the duplicate LUID exists / does skipping
it recover the time" level. The call-path mechanism itself (who spends
the time, where, on which thread) is proven as above.

## PRODUCTION FIX

**NOT AUTHORIZED** by this audit.

## RAW EVIDENCE

local: `C:\Users\fred1\source\PicoView-win-startup\evidence\tmp\windows-startup-callpath-1\`
— headline logs `logs/A|B|C` (20/20/50 runs + summary.json/csv), instrumented
batches `logs/wgpu-decomp` (n=8) and `logs/wgpu-decomp-named` (n=4), uProf
sessions `uprof/{smoke-b,b-1ms,b-1ms-cg,b-cg-2,a-cg-1,c-cg-1}`, tooling
records, runner scripts, `stages-summary.csv`. ~170 files, ≈60 MiB
(uProf session databases dominate). Committed here: this report +
`docs/windows-startup-callpath-1/stages-summary.csv` +
`docs/windows-startup-callpath-1/source-identity.md` + one compressed
archive of the logs (uProf raw databases excluded by size).

## REVIEWS

Two independent adversarial reviewers (fresh context, read-only, raw
evidence access; full verdict texts in
`evidence/tmp/windows-startup-callpath-1/reviews/`).

- measurement: **PASS** — all P50/P95 recomputed from raw logs match to
  the microsecond; single clock domain, headline/profiled segregation,
  gate discipline, and the 88% double-probe claim all reproduce.
- causality: **PASS** — every load-bearing number reproduced; no
  Vulkan/Linux contamination; no overclaimed root cause; next action
  stays measurement-only.
- remaining BLOCKER: none
- remaining MAJOR: none
- MINOR cleanups applied post-review: n=8 vs pooled-n=12 labeling;
  ambient-gate sentence re-cited to the published session (first attempt
  discarded at BATCH-C P95 57.55 after verify 72.05); wgpu-hal chain hop
  re-attributed to nested markers + source (not callgraph frames);
  ≈50–90 ms on-CPU (was 70–100); E90→E91 wait ≈364 ms (was ~356);
  E70→E73 9.1 ms; tree label E100/E110 split; guest_eval n=48 disclosed;
  `dxgkrnl` removed from the evidenced module column (kernel side
  unobservable to user-mode sampling); stale other-session branch note
  in source-identity.md corrected.

## NEXT ACTION (exactly one bounded causal experiment)

Against the top suspect: a reversible, measurement-only intervention that
skips the second same-(VendorId,DeviceId) adapter expose in the vendored
wgpu-hal `enumerate_adapters` (audit branch only), rerun arm B n=20
pristine-vs-patched, predicted shift ≈ −140 ms on E50→E51 (P50) if the
duplicate probe is pure overhead. That experiment stays inside this
audit's authority; any production-grade fix (e.g. upstream adapter-set
dedup, or investigating the VBS duplicate-LUID source with the owner)
requires a separate owner decision.

STOP. No production optimization. #42/#43 untouched. Not merged.
