# WINDOWS-STARTUP-CALLPATH-REALITY-AUDIT-1 — source & tool identity

Recorded 2026-09-14 (local). Companion to
`docs/WINDOWS-STARTUP-CALLPATH-REALITY-AUDIT-1.md`.

## PicoView (audit worktree, isolated)

- path: `C:\Users\fred1\source\PicoView-win-startup`
- branch: `audit/windows-startup-callpath-1`, SHA `491d0a5` (= origin/main
  at freeze; no local code changes — measurement scripts live under the
  gitignored `evidence/` tree only)
- The other session's worktree (`C:\Users\fred1\source\PicoView`) was only
  ever READ (its branch moved during the audit — it sat on
  `exp/cross-os-normalized-desktop-startup-1-slim` at start and on `main`
  at `491d0a5` by review time; no audit artifact ever touched it).

## PocketJS (audit worktree, isolated)

- path: `C:\Users\fred1\source\pocketjs-win-startup`
- branch: `audit/windows-startup-callpath-1`, effective SHA `4b2de0a4`:
  - base `e15674db` (tree `f09cf9fa`) = `picoview-c4-present-pacing` tip =
    campaign candidate `a46eb7e0` + CROSS-OS measurement-only series
    (E00–E190 instrumentation `50e3ed8e`, BENCHMARK_CONFIG to stderr
    `e15674db`)
  - audit-local commits (measurement-only, never upstreamed):
    1. `2ca5dc4c` — arm-B example follows `POCKET_GPU_BACKEND` (Windows
       audit default DX12; explicit VULKAN opt-in preserved)
    2. `66df576f` — vendored `wgpu-hal` 25.0.2 (`vendor/wgpu-hal`,
       `[patch.crates-io]` in `hosts/desktop/Cargo.toml`) + dx12 nested
       markers E50a/b (DXGI enum), E50c/d (expose), indexed E50e0–h2
       (per-adapter D3D12CreateDevice probe + feature queries), routed to
       the host's single E00 monotonic origin via a pocket3d-style hook;
       silent unless the host installs the hook AND `NORMTRACE=1`
    3. `4b2de0a4` — `AUDIT_DXGI_ADAPTER` stderr line (index, name,
       VendorId/DeviceId/AdapterLuid), NORMTRACE-gated
- headline binaries: built from `2ca5dc4c` content (markers not yet
  present) in `target-win-startup-audit` — the timing authority
- profile binaries (uProf PDB): same content,
  `CARGO_PROFILE_RELEASE_DEBUG=2`, `target-win-startup-audit-prof`
- instrumented binaries (nested markers): `66df576f` for the n=8
  decomposition batch, `4b2de0a4` for the n=4 named batch,
  `target-win-startup-audit-wgpu` — analysis aid only, never headline

## Guest artifact

- `picoview-a6-main` windows-app bundle, js 357,862 B / pak 304,944 B —
  byte-identical files referenced read-only from
  `C:\Users\fred1\source\PicoView\evidence\tmp\cross-os-norm-1\dist-winref`
  (frozen single-toolchain bundles per the cross-OS campaign's
  source-identity; per-run identity also embedded in each run's
  `BENCHMARK_CONFIG` guest hash)

## Tools

- AMD uProf CLI 5.3.521.0 (`C:\Program Files\AMD\AMDuProf\bin\AMDuProfCLI.exe`);
  collect syntax taken from the installed help text
  (`Help/text/AMDuProf_Collect_Help.txt`), archived under `tooling/`
- rustc 1.98.1 (48a229cea 2026-09-01) / cargo 1.98.1 (797e8a9bc 2026-08-05),
  host x86_64-pc-windows-msvc — unchanged campaign toolchain
- rustfilt / llvm-tools: not needed (uProf resolved demangled Rust symbols
  + source lines directly from the PDB)

## Machine

Windows 11 Pro build 26200, Ryzen 7 5800H (8C/16T), 28.9 GiB RAM, AMD
Radeon(TM) Graphics iGPU, driver 31.0.21923.11000 (Adrenalin 25.8.1),
2560x1440@60 @1.0x. Hyper-V/VBS active. QQPCRTP resident; WinDefend
service stopped (pre-existing). Vulkan present but unused by this audit.
