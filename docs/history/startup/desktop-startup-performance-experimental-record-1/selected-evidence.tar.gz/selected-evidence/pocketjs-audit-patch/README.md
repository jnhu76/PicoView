# POCKETJS AUDIT PATCHES — measurement-only provenance

These two patches are the **measurement-only** modifications applied to
PocketJS during the Windows startup audits. They were never upstreamed and
never intended for production; they exist so that the instrumentation and the
causal intervention behind the published numbers can be inspected and
re-applied.

Base for both: PocketJS `e15674db1ca9179732c22e5a9a191ba21ebf3e70`
(tree `f09cf9fa…` = campaign candidate `a46eb7e0` + the cross-OS
measurement series `50e3ed8e` + `e15674db`), on the local-only audit branch
`audit/windows-startup-etw-1`.

## wgpu-hal-marker-instrumentation.patch

Full audit series against the base: `e15674db..be58f53c`, restricted to the
files the audits actually modified (the remaining diff hunks of that range
are the vendoring of the published `wgpu-hal` 25.0.2 crate into
`vendor/wgpu-hal` plus lockfiles — i.e. a plain copy of the crates.io
release, not a source modification):

- `hosts/desktop/Cargo.toml` — `[patch.crates-io]` routing wgpu-hal 25 to
  the vendored copy + direct `wgpu-hal` dep for the hook.
- `hosts/desktop/src/main.rs`, `hosts/desktop/examples/norm-b.rs` — hook
  installation and the `BENCHMARK_CONFIG` `driver` field.
- `vendor/wgpu-hal/src/norm_hook.rs` — the audit hook routing wgpu-hal
  events onto the host's single E00 monotonic origin.
- `vendor/wgpu-hal/src/dx12/instance.rs` — nested E50a–h markers around
  `enumerate_adapters`, per-adapter `Adapter::expose`, and the indexed
  `D3D12CreateDevice` probes; **plus the env-gated, reversible, exact-LUID
  skip** (`ETW_AUDIT_SKIP_LUID`) that produced the −152.0 ms causal result.
  It matches exactly one LUID text; there is no dedup by name/VendorId/
  DeviceId.
- `vendor/wgpu-hal/src/dx12/adapter.rs` — per-adapter name/LUID emission
  (`AUDIT_DXGI_ADAPTER`) and the selected-LUID carry used to prove the
  selected adapter in every run.

Behavior when unset (`NORMTRACE` unset, `ETW_AUDIT_SKIP_LUID` unset): no
semantic change — the audits' reviewers verified the default path is
semantically identical to the pristine build.

## wgpu-hal-exact-luid-skip.patch

Focused diff `9a1b8d69..be58f53c` over the same files: the intervention
commit alone (`be58f53c`), i.e. the exact-LUID skip + selected-LUID carry as
they stood when the n=20+20 interleaved experiment ran.

## Commits (local-only branch `audit/windows-startup-etw-1`)

| Commit | Content |
|---|---|
| `2ca5dc4c` | arm-B example follows `POCKET_GPU_BACKEND` (audit default DX12) |
| `66df576f` | vendored wgpu-hal 25.0.2 + dx12 nested markers E50a–h |
| `4b2de0a4` | `AUDIT_DXGI_ADAPTER` name/LUID lines |
| `9a1b8d69` | lockfile for the vendored patch |
| `be58f53c` | env-gated exact-LUID skip + selected-LUID carry |

The call-path audit used the same series minus `be58f53c` (`MEASURED_HEAD`
`4b2de0a4`) on its own local-only branch
`audit/windows-startup-callpath-1` in the PocketJS repository.
